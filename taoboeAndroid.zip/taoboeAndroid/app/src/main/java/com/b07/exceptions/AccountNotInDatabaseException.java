package com.b07.exceptions;

public class AccountNotInDatabaseException extends Exception {
    private static final long serialVersionUID = 0;
}