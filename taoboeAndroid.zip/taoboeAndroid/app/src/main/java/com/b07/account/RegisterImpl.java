package com.b07.account;

import android.content.Context;
import com.b07.database.DatabaseSelectHelperAndroid;
import java.sql.SQLException;
import com.b07.exceptions.RoleIdNotInDatabaseException;
import com.b07.exceptions.UserIdNotInDatabaseException;
import com.b07.models.Customer;

public class RegisterImpl implements Register {

  private int id;
  private int userId;
  private Context context;

  /**
   * Constructor for RegisterImpl
   */
  public RegisterImpl(int id, int userId, Context context) {
    this.id = id;
    this.userId = userId;
    this.context = context;

  }

  /*
   * (non-Javadoc)
   * 
   * @see com.b07.account.Register#registerCustmerAccount(int)
   */
  @Override
  public Customer registerCustomerAccount(int userId)
      throws SQLException, RoleIdNotInDatabaseException, UserIdNotInDatabaseException {
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(context);
    return (Customer) selectHelper.getUserDetails(userId);
  }

}
