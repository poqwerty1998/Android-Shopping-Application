package com.b07.market;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.b07.controllers.AdminInserterController;
import com.b07.controllers.CustomerInserterController;
import com.b07.controllers.ViewBooksActivity;
import com.b07.database.DatabaseInsertHelperAndroid;
import com.b07.database.DatabaseSelectHelperAndroid;
import com.b07.database.DatabaseUpdateHelperAndroid;
import com.b07.serialize.Deserialize;
import com.b07.serialize.Serialize;
import com.b07.exceptions.EmptyStringException;
import com.b07.exceptions.InvalidPriceException;
import com.b07.exceptions.InvalidQuantityException;
import com.b07.exceptions.ItemIdNotInDatabaseException;
import com.b07.exceptions.ItemNameAlreadyInDatabaseException;
import com.b07.exceptions.UserIdNotInDatabaseException;
import com.b07.taoboe.R;
import com.b07.models.Admin;
import com.b07.views.ActiveAccountListView;
import com.b07.views.InactiveAccountListView;
import java.math.BigDecimal;
import java.util.ArrayList;

public class AdminInterfaceActivity extends AppCompatActivity {

  private int adminId;
  private String adminName;
  private Admin admin;


  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_admin_interface);
    TextView currentUserId = findViewById(R.id.adminUserId);
    TextView currentUserName = findViewById(R.id.adminName);

    Button logOffButton = findViewById(R.id.logOffButton);
    Button viewBooksButton = findViewById(R.id.viewBooksButton);
    Button addNewItemToStoreButton = findViewById(R.id.addNewItemToStoreButton);
    Button restockInventoryButton = findViewById(R.id.restockInventoryButton);
    Button createNewCustomerButton = findViewById(R.id.createNewCustomerButton);
    Button createNewAdminButton = findViewById(R.id.createNewAdminButton);
    Button checkCustActiveAccountsButton = findViewById(R.id.checkCustActiveAccountsButton);
    Button checkCustInactiveAccountsButton = findViewById(R.id.checkCustInactiveAccountsButton);
    Button serializeDatabaseButton = findViewById(R.id.serializeDatabaseButton);
    Button deserializeDatabaseButton = findViewById(R.id.deserializeDatabaseButton);

    logOffButton.setOnClickListener(buttonListener);
    viewBooksButton.setOnClickListener(buttonListener);
    addNewItemToStoreButton.setOnClickListener(buttonListener);
    restockInventoryButton.setOnClickListener(buttonListener);
    createNewCustomerButton.setOnClickListener(buttonListener);
    createNewAdminButton.setOnClickListener(buttonListener);
    checkCustActiveAccountsButton.setOnClickListener(buttonListener);
    checkCustInactiveAccountsButton.setOnClickListener(buttonListener);
    serializeDatabaseButton.setOnClickListener(buttonListener);
    deserializeDatabaseButton.setOnClickListener(buttonListener);

    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(
        getApplicationContext());
    this.adminId = getIntent().getExtras().getInt("adminId");
    try {
      Admin adminObject = (Admin) selectHelper.getUserDetails(this.adminId);
      this.admin = adminObject;
      this.adminName = admin.getName();
      currentUserId.setText("User ID : " + adminId);
      currentUserName.setText(this.adminName);
    } catch (UserIdNotInDatabaseException e) {
      Toast.makeText(getApplicationContext(), "Something went wrong with Admin",
          Toast.LENGTH_SHORT).show();
    }
  }

  private View.OnClickListener buttonListener = new View.OnClickListener() {
    public void onClick(View v) {
      final Intent nextIntent;
      switch (v.getId()) {
        case R.id.logOffButton:
          nextIntent = new Intent(AdminInterfaceActivity.this, MainActivity.class);
          AlertDialog logOffDialog = new AlertDialog.Builder(AdminInterfaceActivity.this).
              create();
          logOffDialog.setMessage("Are you sure you want to log off?");
          logOffDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Yes",
              new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                  dialog.dismiss();
                  startActivity(nextIntent);
                  Toast.makeText(getApplicationContext(), "Logged off",
                      Toast.LENGTH_SHORT).show();
                }
              });
          logOffDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "No",
              new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                  dialog.dismiss();
                }
              });
          logOffDialog.show();
          return;
        case R.id.viewBooksButton:
          //listview
          // charles
          nextIntent = new Intent(AdminInterfaceActivity.this,
              ViewBooksActivity.class);
          startActivity(nextIntent);
          return;
        case R.id.addNewItemToStoreButton:
          addItemDialog();
          return;
        case R.id.restockInventoryButton:
          restockItemDialog();
          return;
        case R.id.createNewCustomerButton:
          nextIntent = new Intent(AdminInterfaceActivity.this,
              CustomerInserterController.class);
          nextIntent.putExtra("isFirstRun", false);
          startActivity(nextIntent);
          return;
        case R.id.createNewAdminButton:
          nextIntent = new Intent(AdminInterfaceActivity.this,
              AdminInserterController.class);
          nextIntent.putExtra("isFirstRun", false);
          startActivity(nextIntent);
          return;
        case R.id.checkCustActiveAccountsButton:
          getActiveInactive(true);
          return;
        case R.id.checkCustInactiveAccountsButton:
          getActiveInactive(false);
          return;
        case R.id.serializeDatabaseButton:
          //java code
          serializer();
          // show toast if success full
          //kevin
          return;
        case R.id.deserializeDatabaseButton:
          // java code
          // show toast if success full
          deserializer();
          //kevin
          return;
      }

    }
  };

  @Override
  public void onBackPressed() {
  }

  private void getActiveInactive(final boolean active) {
    View view = LayoutInflater.from(this).inflate(R.layout.dialog_active_inactive_account,
        null);
    final EditText userId = view.findViewById(R.id.inactive_account_userId);

    AlertDialog.Builder builder = new AlertDialog.Builder(this);
    builder.setMessage("What User Id ?").setView(view);
    builder.setPositiveButton("next", new DialogInterface.OnClickListener() {
      @Override
      public void onClick(DialogInterface dialog, int which) {
        if (userId.getText().toString().isEmpty()) {
          Toast.makeText(getApplicationContext(), "Empty Field", Toast.LENGTH_SHORT).show();
        } else {
          String userInput = userId.getText().toString();
          if (active) {
            dialog.dismiss();
            getActiveInactiveHelper(userInput, active);
          } else {
            dialog.dismiss();
            getActiveInactiveHelper(userInput, active);
          }
        }
      }
    });
    builder.setNegativeButton("cancel", null);
    builder.setCancelable(true);
    AlertDialog alert = builder.create();
    alert.show();
  }

  private void getActiveInactiveHelper(String userId, boolean active) {
    Intent nextIntent;

    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(
        getApplicationContext());
    ArrayList<String> accountId = new ArrayList<String>();
    try {

      if (active) {
        for (int i : selectHelper.getUserActiveAccounts((Integer.parseInt(userId)))) {
          accountId.add("Account ID : " + i);
        }
        if (accountId.isEmpty()) {
          Toast.makeText(getApplicationContext(), "No accounts to be displayed", Toast.LENGTH_SHORT)
              .show();
        } else {
          nextIntent = new Intent(AdminInterfaceActivity.this,
              ActiveAccountListView.class);
          nextIntent.putStringArrayListExtra("active", accountId);
          startActivity(nextIntent);
        }

      } else {
        for (int i : selectHelper.getUserInactiveAccounts((Integer.parseInt(userId)))) {
          accountId.add("Account ID : " + i);
        }
        if (accountId.isEmpty()) {
          Toast.makeText(getApplicationContext(), "No accounts to be displayed", Toast.LENGTH_SHORT)
              .show();
        } else {
          nextIntent = new Intent(AdminInterfaceActivity.this,
              InactiveAccountListView.class);
          nextIntent.putStringArrayListExtra("inactive", accountId);
          startActivity(nextIntent);
        }
      }
    } catch (UserIdNotInDatabaseException e) {
      Toast.makeText(getApplicationContext(), "failed", Toast.LENGTH_SHORT).show();
    }

  }

  private void addItemDialog() {
    View viewNewItem = LayoutInflater.from(AdminInterfaceActivity.this)
        .inflate(R.layout.additem_dialog, null);
    final EditText editTextItemName = viewNewItem.findViewById(R.id.itemNameField);
    final EditText editTextItemPrice = viewNewItem.findViewById(R.id.itemPriceField);
    final EditText editTextItemQuantity = viewNewItem.findViewById(R.id.itemQuantityField);

    AlertDialog addItemDialog = new AlertDialog.Builder(AdminInterfaceActivity.this).
        create();

    addItemDialog.setView(viewNewItem);
    addItemDialog.setTitle("Add Item");
    addItemDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Add",
        new DialogInterface.OnClickListener() {
          public void onClick(DialogInterface dialog, int which) {
            Context context = getApplicationContext();
            if (editTextItemName.getText().toString().isEmpty()
                || editTextItemQuantity.getText().toString().isEmpty()
                || editTextItemPrice.getText().toString().isEmpty()) {
              Toast.makeText(context, "Empty Field(s)", Toast.LENGTH_SHORT).show();
            } else {
              String name = editTextItemName.getText().toString();
              BigDecimal price = new BigDecimal(editTextItemPrice.getText().toString());
              int quantity = Integer.valueOf(editTextItemQuantity.getText().toString());
              DatabaseInsertHelperAndroid insertHelper = new DatabaseInsertHelperAndroid(context);
              try {
                int itemId = insertHelper.insertItem(name, price);
                int inventoryId = insertHelper
                    .insertInventory(itemId, quantity);
                if (itemId == -1 || inventoryId == -1) {
                  Toast.makeText(context, "Add item unsuccessful", Toast.LENGTH_SHORT).show();
                } else {
                  Toast.makeText(context, "Add item successful", Toast.LENGTH_SHORT).show();
                }
              } catch (EmptyStringException e) {
                Toast.makeText(context, "Empty string", Toast.LENGTH_SHORT).show();
              } catch (InvalidPriceException e) {
                Toast.makeText(context, "Invalid price", Toast.LENGTH_SHORT).show();
              } catch (InvalidQuantityException e) {
                Toast.makeText(context, "Invalid quantity", Toast.LENGTH_SHORT).show();
              } catch (ItemIdNotInDatabaseException e) {
                Toast.makeText(context, "ID not in database", Toast.LENGTH_SHORT).show();
              } catch (ItemNameAlreadyInDatabaseException e) {
                Toast.makeText(context, "Name already in database", Toast.LENGTH_SHORT).show();
              }
            }
          }
        });
    addItemDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Cancel",
        new DialogInterface.OnClickListener() {
          public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
          }
        });
    addItemDialog.show();
  }

  private void restockItemDialog() {
    View restockInventoryView = LayoutInflater.from(AdminInterfaceActivity.this)
        .inflate(R.layout.restockitem_dialog, null);
    final EditText editTextRestockItemId = restockInventoryView
        .findViewById(R.id.restockItemIdField);
    final EditText editTextRestockItemQuantity = restockInventoryView
        .findViewById(R.id.restockItemQuantityField);

    AlertDialog restockItemDialog = new AlertDialog.Builder(AdminInterfaceActivity.this).
        create();

    restockItemDialog.setView(restockInventoryView);
    restockItemDialog.setTitle("Restock Item");
    restockItemDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Restock",
        new DialogInterface.OnClickListener() {
          public void onClick(DialogInterface dialog, int which) {
            Context context = getApplicationContext();
            if (editTextRestockItemId.getText().toString().isEmpty()
                || editTextRestockItemQuantity.getText().toString().isEmpty()) {
              Toast.makeText(context, "Empty Field(s)", Toast.LENGTH_SHORT).show();
            } else {
              int itemId = Integer.valueOf(editTextRestockItemId.getText().toString());
              int quantity = Integer.valueOf(editTextRestockItemQuantity.getText().toString());
              DatabaseUpdateHelperAndroid updateHelper = new DatabaseUpdateHelperAndroid(context);
              DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(context);
              try {
                int itemQuantity = selectHelper.getInventoryQuantity(itemId);
                boolean successful = updateHelper
                    .updateInventoryQuantity(quantity + itemQuantity, itemId);
                if (successful) {
                  Toast.makeText(context, "Restock item successful", Toast.LENGTH_SHORT).
                      show();
                } else {
                  Toast.makeText(context, "Restock item unsuccessful", Toast.LENGTH_SHORT).
                      show();
                }
              } catch (ItemIdNotInDatabaseException e) {
                Toast.makeText(context, "ID not in database", Toast.LENGTH_SHORT).show();
              }
            }
          }
        });
    restockItemDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Cancel",
        new DialogInterface.OnClickListener() {
          public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
          }
        });
    restockItemDialog.show();
  }

  private void deserializer() {
    try {
      Deserialize deserializer = new Deserialize(getApplicationContext());
      deserializer.deserialize();
    } catch (Exception e) {
      Toast.makeText(getApplicationContext(), "You cant deserialize dumbie",
          Toast.LENGTH_SHORT)
          .show();
    }
  }

  private void serializer() {
    try {
      Serialize serializer = new Serialize(getApplicationContext());
      serializer.serialize();
    } catch (Exception e) {
      Toast.makeText(getApplicationContext(), "You cant serialize dumbie", Toast.LENGTH_SHORT)
          .show();
    }
  }

}
