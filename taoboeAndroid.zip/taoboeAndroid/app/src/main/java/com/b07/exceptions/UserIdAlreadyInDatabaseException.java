package com.b07.exceptions;

public class UserIdAlreadyInDatabaseException extends Exception {

  private static final long serialVersionUID = 6392401173689666101L;

  public UserIdAlreadyInDatabaseException() {
  }

  public UserIdAlreadyInDatabaseException(String message) {
    super(message);  }

  public UserIdAlreadyInDatabaseException(Throwable cause) {
    super(cause);
  }

  public UserIdAlreadyInDatabaseException(String message, Throwable cause) {
    super(message, cause);
  }

  public UserIdAlreadyInDatabaseException(String message, Throwable cause,
      boolean enableSuppression, boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }

}
