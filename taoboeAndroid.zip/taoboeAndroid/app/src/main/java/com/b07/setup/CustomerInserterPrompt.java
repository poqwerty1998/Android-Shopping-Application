package com.b07.setup;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import com.b07.database.DatabaseInsertHelperAndroid;
import com.b07.exceptions.EmptyStringException;
import com.b07.controllers.CustomerInserterController;
import com.b07.market.MainActivity;
import com.b07.taoboe.R;

public class CustomerInserterPrompt extends AppCompatActivity {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_customer_inserter_prompt);
    Button exitButton = findViewById(R.id.createPromptNoButton);
    Button goButton = findViewById(R.id.createPromptYesButton);

    exitButton.setOnClickListener(buttonListener);
    goButton.setOnClickListener(buttonListener);
  }

  private View.OnClickListener buttonListener = new View.OnClickListener() {
    public void onClick(View v) {
      DatabaseInsertHelperAndroid insertHelper = new DatabaseInsertHelperAndroid(
          getApplicationContext());
      try {
        insertHelper.insertRole("CUSTOMER");
      } catch (EmptyStringException e) {
        Toast.makeText(getApplicationContext(), "Insert role failed", Toast.LENGTH_SHORT).show();
      }
      Intent nextIntent;
      switch (v.getId()) {

        case R.id.createPromptNoButton:
          nextIntent = new Intent(CustomerInserterPrompt.this,
              MainActivity.class);
          Toast.makeText(getApplicationContext(), "Setup Complete!", Toast.LENGTH_SHORT).show();
          finish();
          startActivity(nextIntent);
          return;
        case R.id.createPromptYesButton:
          nextIntent = new Intent(CustomerInserterPrompt.this,
              CustomerInserterController.class);
          nextIntent.putExtra("isFirstRun", true);
          finish();
          startActivity(nextIntent);
          return;
      }
    }
  };
}
