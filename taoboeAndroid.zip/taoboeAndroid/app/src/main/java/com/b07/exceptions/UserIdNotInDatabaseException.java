package com.b07.exceptions;

public class UserIdNotInDatabaseException extends Exception {

  private static final long serialVersionUID = 1305176560671152613L;

  public UserIdNotInDatabaseException() {
  }

  public UserIdNotInDatabaseException(String message) {
    super(message);
  }

  public UserIdNotInDatabaseException(Throwable cause) {
    super(cause);
  }

  public UserIdNotInDatabaseException(String message, Throwable cause) {
    super(message, cause);
  }

  public UserIdNotInDatabaseException(String message, Throwable cause, boolean enableSuppression,
      boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }

}
