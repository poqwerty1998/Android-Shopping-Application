package com.b07.market;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.b07.account.CustomerAccount;
import com.b07.database.DatabaseInsertHelperAndroid;
import com.b07.database.DatabaseSelectHelperAndroid;
import com.b07.database.DatabaseUpdateHelperAndroid;
import com.b07.exceptions.ItemIdNotInDatabaseException;
import com.b07.exceptions.UserIdNotInDatabaseException;
import com.b07.inventory.Item;
import com.b07.store.ShoppingCart;
import com.b07.taoboe.R;
import com.b07.models.Customer;
import com.b07.views.AccountsListView;
import com.b07.views.AddRemoveItemListView;
import com.b07.views.ShoppingCartListView;
import java.math.BigDecimal;
import java.util.ArrayList;

public class CustomerInterfaceActivity extends AppCompatActivity {

  private int customerId;
  private String customerName;
  private int currentCustomerAccount;
  private BigDecimal currentTotalPrice;
  private Customer customer;
  private ShoppingCart cart;
  private TextView currentAccount;
  private TextView totalPrice;
  private SensorManager sm;
  private float currentAcceleration;
  private float lastAcceleration;
  private float shake;


  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_customer_interface);
    TextView currentUserId = findViewById(R.id.customerUserId);
    TextView currentUserName = findViewById(R.id.customerName);
    this.currentAccount = findViewById(R.id.accountIdField);
    this.totalPrice = findViewById(R.id.totalPrice);

    Button LogOffButton = findViewById(R.id.logOffButton);
    Button viewShoppingCartButton = findViewById(R.id.viewShoppingCartButton);
    Button ItemsButton = findViewById(R.id.addRemoveItemsButton);
    Button checkoutButton = findViewById(R.id.checkoutButton);
    Button viewAccountsButton = findViewById(R.id.viewAccountsButton);
    Button registerAccountButton = findViewById(R.id.registerAccountButton);

    LogOffButton.setOnClickListener(buttonListener);
    viewShoppingCartButton.setOnClickListener(buttonListener);
    ItemsButton.setOnClickListener(buttonListener);
    checkoutButton.setOnClickListener(buttonListener);
    viewAccountsButton.setOnClickListener(buttonListener);
    registerAccountButton.setOnClickListener(buttonListener);

    sm = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
    sm.registerListener(sensorListener, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
        SensorManager.SENSOR_DELAY_NORMAL);
    shake = 0.00f;
    currentAcceleration = SensorManager.GRAVITY_EARTH;
    lastAcceleration = SensorManager.GRAVITY_EARTH;

    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(
        getApplicationContext());
    Customer customer = null;

    // to get the customer id from last activity
    this.customerId = getIntent().getExtras().getInt("customerUserId");

    // attempt to create customer object
    try {
      customer = (Customer) selectHelper.getUserDetails(customerId);
    } catch (UserIdNotInDatabaseException e) {
      Toast.makeText(getApplicationContext(), "Something went wrong with customer",
          Toast.LENGTH_SHORT).show();
    }

    // set fields
    this.cart = new ShoppingCart(customer, getApplicationContext());
    this.customerName = customer.getName();
    this.currentCustomerAccount = -1;
    this.currentTotalPrice = cart.getTotal();
    this.customer = customer;

    // set text views
    currentUserName.setText(customerName);
    currentUserId.setText("User ID : " + customerId);
    if (!(this.currentCustomerAccount == -1)) {
      currentAccount.setText("Account ID : " + this.currentCustomerAccount);
    } else {
      currentAccount.setText("Account ID : None");
    }
    totalPrice.setText("Total Price : " + currentTotalPrice.toPlainString());
  }

  private View.OnClickListener buttonListener = new View.OnClickListener() {
    public void onClick(View v) {
      final Intent nextIntent;
      switch (v.getId()) {
        case R.id.logOffButton:
          nextIntent = new Intent(CustomerInterfaceActivity.this, MainActivity.class);
          AlertDialog logOffDialog = new AlertDialog.Builder(CustomerInterfaceActivity.this)
              .create();
          logOffDialog.setMessage("Are you sure you want to log off?");
          logOffDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Yes",
              new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                  dialog.dismiss();
                  startActivity(nextIntent);
                  if (currentCustomerAccount != -1) {
                    DatabaseInsertHelperAndroid insertHelper = new DatabaseInsertHelperAndroid(
                        getApplicationContext());
                    for (Item i : cart.getItemsAndQuantity().keySet()) {
                      try {
                        insertHelper.insertAccountLine(currentCustomerAccount, i.getId(),
                            cart.getItemQuantity(i));
                      } catch (Exception e) {
                        Toast.makeText(getApplication(), "Storing Shopping Cart Failed",
                            Toast.LENGTH_SHORT).show();
                      }
                    }
                  }
                  Toast.makeText(getApplicationContext(), "Logged off",
                      Toast.LENGTH_SHORT).show();
                }
              });
          logOffDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "No",
              new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                  dialog.dismiss();
                }
              });
          logOffDialog.show();
          return;
        case R.id.viewShoppingCartButton:
          viewCart();
          return;
        case R.id.addRemoveItemsButton:
          addRemoveItem();
          return;
        case R.id.checkoutButton:
          checkout();
          return;
        case R.id.viewAccountsButton:
          DatabaseInsertHelperAndroid insertHelper = new DatabaseInsertHelperAndroid(
              getApplicationContext());
          if (currentCustomerAccount != -1) {
            for (Item i : cart.getItemsAndQuantity().keySet()) {
              try {
                insertHelper
                    .insertAccountLine(currentCustomerAccount, i.getId(), cart.getItemQuantity(i));
              } catch (Exception e) {
                Toast.makeText(getApplication(), "Storing Shopping Cart Failed", Toast.LENGTH_SHORT)
                    .show();
              }
            }
          }
          viewAccounts();
          return;
        case R.id.registerAccountButton:
          nextIntent = new Intent(CustomerInterfaceActivity.this, RegisterActivity.class);
          startActivity(nextIntent);
          return;
      }
    }
  };

  @Override
  public void onBackPressed() {
  }

  private final SensorEventListener sensorListener = new SensorEventListener() {
    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
      float x = sensorEvent.values[0];
      float y = sensorEvent.values[1];
      float z = sensorEvent.values[2];

      lastAcceleration = currentAcceleration;
      currentAcceleration = (float) Math.sqrt((double) (x * x + y * y + z * z));
      float delta = currentAcceleration - lastAcceleration;
      shake = shake * 0.9f + delta;
      if (shake > 8) {
        checkout();
        shake = 0.00f;
      }
    }

    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }
  };


  private void viewCart() {
    Intent nextIntent;
    nextIntent = new Intent(CustomerInterfaceActivity.this, ShoppingCartListView.class);
    ArrayList<Integer> quantity = new ArrayList<Integer>();
    ArrayList<String> itemNames = new ArrayList<String>();
    for (Item i : cart.getItemsAndQuantity().keySet()) {
      itemNames.add(i.getName());
      quantity.add(cart.getItemQuantity(i));
    }
    nextIntent.putStringArrayListExtra("itemNames", itemNames);
    nextIntent.putIntegerArrayListExtra("quantity", quantity);
    startActivity(nextIntent);
  }

  private void viewAccounts() {
    Intent nextIntent;
    nextIntent = new Intent(CustomerInterfaceActivity.this, AccountsListView.class);
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(
        getApplicationContext());
    ArrayList<Integer> account = new ArrayList<Integer>();

    try {
      for (int id : selectHelper.getUserAccounts(this.customerId)) {
        account.add(id);
      }
      if (account.isEmpty()) {
        Toast.makeText(getApplication(), "You have no accounts", Toast.LENGTH_SHORT).show();
      } else {
        nextIntent.putIntegerArrayListExtra("account", account);
        startActivityForResult(nextIntent, 1);
      }
    } catch (UserIdNotInDatabaseException e) {
      Toast.makeText(getApplication(), "User does not exist", Toast.LENGTH_SHORT).show();
    } catch (Exception e) {
      Toast.makeText(getApplication(), "next page fail", Toast.LENGTH_SHORT).show();
    }
  }

  private void checkout() {
    if (!cart.getItemsAndQuantity().keySet().isEmpty()) {
      try {
        cart.checkOut(cart);
        cart.clearCart();
        DatabaseUpdateHelperAndroid updateHelper = new DatabaseUpdateHelperAndroid(
            getApplicationContext());
        updateHelper.updateAccountStatus(currentCustomerAccount, false);
      } catch (Exception e) {
        Toast.makeText(getApplicationContext(), "failed to checkout", Toast.LENGTH_SHORT)
            .show();
      }
      Toast.makeText(getApplicationContext(), "checkout successfully", Toast.LENGTH_SHORT)
          .show();
    } else {
      Toast.makeText(getApplicationContext(), "failed to checkout", Toast.LENGTH_SHORT)
          .show();
    }
  }

  private void addRemoveItem() {
    Intent nextIntent;
    nextIntent = new Intent(CustomerInterfaceActivity.this, AddRemoveItemListView.class);
    nextIntent.putStringArrayListExtra("itemInfo", itemInfo());
    startActivityForResult(nextIntent, 2);
  }

  private ArrayList<String> itemInfo() {
    ArrayList<String> result = new ArrayList<String>();
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(
        getApplicationContext());
    try {
      for (Item item : selectHelper.getInventory().getItemMap().keySet()) {
        int quantity = selectHelper.getInventoryQuantity(item.getId());
        result.add(item.getName() + "( id " + item.getId() + ")" +
            " quantity: " + quantity +
            " price: " + item.getPrice());
      }
    } catch (ItemIdNotInDatabaseException e) {
      Toast.makeText(getApplicationContext(), "fail", Toast.LENGTH_SHORT).show();
    }
    return result;
  }

  @Override
  public void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    switch (requestCode) {
      case (1): {
        if (resultCode == this.RESULT_OK) {
          DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(
              getApplicationContext());
          int newId = data.getExtras().getInt("currentAccountId");
          this.currentCustomerAccount = newId;
          currentAccount.setText("Account ID : " + newId);
          try {
            CustomerAccount account = new CustomerAccount(newId, this.customerId,
                getApplicationContext());
            this.cart = account.getPreviousShoppingCart();
            this.currentTotalPrice = cart.getTotal();
            this.totalPrice.setText("Total Price : " + this.cart.getTotal().toPlainString());
          } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "Error Occured", Toast.LENGTH_SHORT).show();
          }
          Toast
              .makeText(getApplicationContext(), "Account changed to :" + newId, Toast.LENGTH_SHORT)
              .show();
        }
        break;
      }
      case (2): {
        DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(
            getApplicationContext());
        try {
          int itemId = data.getExtras().getInt("itemId");
          int quantity = data.getExtras().getInt("quantity");
          if (resultCode == this.RESULT_OK) {
            if (data.getExtras().getBoolean("action")) {
              try {
                if (quantity > 0) {
                  Item item = selectHelper.getItem(itemId);
                  this.cart.addItem(item, quantity);
                  this.currentTotalPrice = cart.getTotal();
                  this.totalPrice.setText("Total Price : " + this.cart.getTotal().toPlainString());
                  Toast.makeText(getApplicationContext(), quantity + " item " + itemId + " added",
                      Toast.LENGTH_SHORT).show();

                } else {
                  Toast.makeText(getApplicationContext(), "Quantity must be 1 or greater",
                      Toast.LENGTH_LONG)
                      .show();
                }
              } catch (ItemIdNotInDatabaseException e) {
                Toast.makeText(getApplicationContext(), "Error occured with item",
                    Toast.LENGTH_SHORT)
                    .show();
              } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "Error Occured", Toast.LENGTH_SHORT).show();
              }
            } else {
              try {
                Item item = selectHelper.getItem(itemId);
                this.cart.removeItem(item, quantity);
                this.currentTotalPrice = cart.getTotal();
                this.totalPrice.setText("Total Price : " + this.cart.getTotal().toPlainString());
                Toast.makeText(getApplicationContext(), quantity + " item " + itemId + " removed",
                    Toast.LENGTH_SHORT).show();
              } catch (ItemIdNotInDatabaseException e) {
                Toast.makeText(getApplicationContext(), "Error occured with item",
                    Toast.LENGTH_SHORT)
                    .show();
              } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "Error Occured", Toast.LENGTH_SHORT).show();
              }
            }
          }
        } catch (Exception e) {
          Toast.makeText(getApplicationContext(), "No action", Toast.LENGTH_SHORT).show();
        }
        break;
      }
    }
  }
}



