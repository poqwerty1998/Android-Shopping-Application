package com.b07.exceptions;

public class InvalidAddressException extends Exception {
  
  private static final long serialVersionUID = -425617495458085336L;

  public InvalidAddressException() {
    
  }

  public InvalidAddressException(String message) {
    super(message);
  }

  public InvalidAddressException(Throwable cause) {
    super(cause);
  }

  public InvalidAddressException(String message, Throwable cause) {
    super(message, cause);
  }

  public InvalidAddressException(String message, Throwable cause, boolean enableSuppression,
      boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }

}
