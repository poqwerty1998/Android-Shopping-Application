package com.b07.database;

import java.math.BigDecimal;

import com.b07.exceptions.AccountNotInDatabaseException;
import com.b07.exceptions.ItemIdNotInDatabaseException;
import com.b07.exceptions.RoleIdNotInDatabaseException;
import com.b07.exceptions.UserIdNotInDatabaseException;

import android.content.Context;

/**
 * Created by kevinshen on 2017-11-29.
 */

public class DatabaseUpdateHelperAndroid {

  private Context activityContext;

  public DatabaseUpdateHelperAndroid(Context activityContext) {
    this.activityContext = activityContext;

  }

  /**
   * Updates the role.
   *
   * @param name in string
   * @param id of role to be
   * @return true or false based on if it works
   * @throws RoleIdNotInDatabaseException thrown if id doedsn't exist
   */
  public boolean updateRole(String name, int id) throws RoleIdNotInDatabaseException {
    // make result boolean
    // create a new object to update
    DatabaseDriverAndroid updateDatabase = new DatabaseDriverAndroid(activityContext);
    // create a select helper
    DatabaseSelectHelperAndroid helper = new DatabaseSelectHelperAndroid(activityContext);
    boolean result = false;
    try {
      // validate inputs
      if (!(helper.getRole(id).isEmpty() || name.isEmpty() || id <= 0)) {
        // stores the boolean if successful update or not
        result = updateDatabase.updateRoleName(name, id);
      }
    } catch (RoleIdNotInDatabaseException e) {
      throw new RoleIdNotInDatabaseException();
    } finally {
      // close the db object after use
      updateDatabase.close();
      // return if update was successful
      return result;
    }
  }

  /**
   * Updates the role.
   *
   * @param accountId as an integer.
   * @param active boolean, whether the account is active or not.
   * @return true or false based on if it works.
   */
  public boolean updateAccountStatus(int accountId, boolean active)
      throws AccountNotInDatabaseException {
    // make result boolean
    boolean result = false;
    // create a new object to update
    DatabaseDriverAndroid updateDatabase = new DatabaseDriverAndroid(activityContext);
    // create a select helper to validate inputs
    DatabaseSelectHelperAndroid helper = new DatabaseSelectHelperAndroid(activityContext);
    // validate inputs
    try {
      if (!(helper.getAccountDetails(accountId).isEmpty())) {
        result = updateDatabase.updateAccountStatus(accountId, active);
      }
    } catch (AccountNotInDatabaseException e) {
      throw new AccountNotInDatabaseException();
    } finally {
      // close the db object after use
      updateDatabase.close();
      // return if update was successful
      return result;
    }

  }

  /**
   * validates if inputs are correct then updates the db with inputs.
   *
   * @param quantity of item
   * @param id of item in inventory
   * @return true if update was successful false otherwise
   * @throws ItemIdNotInDatabaseException thrown when the id does not exist in db
   */
  public boolean updateInventoryQuantity(int quantity, int id) throws ItemIdNotInDatabaseException {
    // make result boolean
    boolean result = false;
    // create a new object to update
    DatabaseDriverAndroid updateDatabase = new DatabaseDriverAndroid(activityContext);
    // create a select helper to validate inputs
    DatabaseSelectHelperAndroid helper = new DatabaseSelectHelperAndroid(activityContext);
    try {
      if (!(quantity < 0 || id < 0 || helper.getInventoryQuantity(id) < 0)) {
        result = updateDatabase.updateInventoryQuantity(quantity, id);
      }
    } catch (ItemIdNotInDatabaseException e) {
      throw new ItemIdNotInDatabaseException();
    } finally {
      // close the db object after use
      updateDatabase.close();
      // return if update was successful
      return result;
    }
  }

  /**
   * validates if inputs are correct then updates the db with inputs.
   *
   * @param name of Item
   * @param id of Item
   * @return true if update was successful false otherwise
   * @throws ItemIdNotInDatabaseException thrown when the id does not exist in db
   */
  public boolean updateItemName(String name, int id) throws ItemIdNotInDatabaseException {
    // make result boolean
    boolean result = false;
    // create a new object to update
    DatabaseDriverAndroid updateDatabase = new DatabaseDriverAndroid(activityContext);
    // create a select helper to validate inputs
    DatabaseSelectHelperAndroid helper = new DatabaseSelectHelperAndroid(activityContext);
    if (name.isEmpty() || id <= 0 || helper.getItem(id) == null) {
      return result;
    }
    result = updateDatabase.updateItemName(name, id);
    // close the db object after use
    updateDatabase.close();
    // return if update was successful
    return result;
  }

  /**
   * validates if inputs are correct then updates the db with inputs.
   *
   * @param price a big decimal value of price
   * @param id of item
   * @return true if update was succesful false otherwise
   * @throws ItemIdNotInDatabaseException thrown when the id does not exist in db
   */
  public boolean updateItemPrice(BigDecimal price, int id) throws ItemIdNotInDatabaseException {
    // make result boolean
    boolean result = false;
    // create a new object to update
    DatabaseDriverAndroid updateDatabase = new DatabaseDriverAndroid(activityContext);
    // create a select helper to validate inputs
    DatabaseSelectHelperAndroid helper = new DatabaseSelectHelperAndroid(activityContext);
    // create big decimal to validate input
    try {
      BigDecimal zero = new BigDecimal("0");
      // validate inputs
      if (zero.compareTo(price) == 1 || id <= 0 || helper.getItem(id) == null) {
        return result;
      }
      result = updateDatabase.updateItemPrice(price, id);
    } catch (ItemIdNotInDatabaseException e) {
      throw new ItemIdNotInDatabaseException();
    } finally {
      // close the db object after use
      updateDatabase.close();
      // return if update was successful
      return result;
    }


  }

  /**
   * validates if inputs are correct then updates the db with inputs.
   *
   * @param address of user
   * @param id of user
   * @return true if update was succesful false otherwise
   * @throws UserIdNotInDatabaseException thrown when the id does not exist in db
   */
  public boolean updateUserAddress(String address, int id) throws UserIdNotInDatabaseException {
    // make result boolean
    boolean result = false;
    // create a new object to update
    DatabaseDriverAndroid updateDatabase = new DatabaseDriverAndroid(activityContext);
    // create a select helper to validate inputs
    DatabaseSelectHelperAndroid helper = new DatabaseSelectHelperAndroid(activityContext);
    try {
      // validate inputs
      if (address.isEmpty() || id <= 0 || helper.getUserDetails(id) == null) {
        return result;
      }
      result = updateDatabase.updateUserAddress(address, id);
    } catch (UserIdNotInDatabaseException e) {
      throw new UserIdNotInDatabaseException();
    } finally {
      // close the db object after use
      updateDatabase.close();
      // return if update was successful
      return result;
    }
  }

  /**
   * validates if inputs are correct then updates the db with inputs.
   *
   * @param age of user
   * @param id of user
   * @return true if update was successful false otherwise
   * @throws UserIdNotInDatabaseException thrown when the id does not exist in db
   */
  public boolean updateUserAge(int age, int id) throws UserIdNotInDatabaseException {
    // make result boolean
    boolean result = false;
    // create a new object to update
    DatabaseDriverAndroid updateDatabase = new DatabaseDriverAndroid(activityContext);
    // create a select helper to validate inputs
    DatabaseSelectHelperAndroid helper = new DatabaseSelectHelperAndroid(activityContext);
    try {
      // validate the inputs
      if (!((age <= 0 || id <= 0 || helper.getUserDetails(id) == null))) {
        result = updateDatabase.updateUserAge(age, id);
      }
    } catch (UserIdNotInDatabaseException e) {
      throw new UserIdNotInDatabaseException();
    } finally {
      // close the db object after use
      updateDatabase.close();
      // return if update was successful
      return result;
    }
  }

  /**
   * validates if inputs are correct then updates the db with inputs.
   *
   * @param name of user
   * @param id of user
   * @return true if update was succesful false otherwise
   * @throws UserIdNotInDatabaseException thrown when the id does not exist in db
   */
  public boolean updateUserName(String name, int id) throws UserIdNotInDatabaseException {
    // make result boolean
    boolean result = false;
    // create a new object to update
    DatabaseDriverAndroid updateDatabase = new DatabaseDriverAndroid(activityContext);
    // create a select helper to validate inputs
    DatabaseSelectHelperAndroid helper = new DatabaseSelectHelperAndroid(activityContext);
    // validate inputs
    try {
      if (!(name.isEmpty() || id <= 0 || helper.getUserDetails(id) == null)) {
        result = updateDatabase.updateUserName(name, id);
      }
    } catch (UserIdNotInDatabaseException e) {
      throw new UserIdNotInDatabaseException();
    } finally {
      // close the db object after use
      updateDatabase.close();
      // return if update was successful
      return result;
    }
  }

  /**
   * validates if inputs are correct then updates the db with inputs.
   *
   * @param password of user
   * @param id of user
   * @return true if update was succesful false otherwise
   * @throws UserIdNotInDatabaseException thrown when the id does not exist in db
   */
  public boolean updateUserPassword(String password, int id) throws UserIdNotInDatabaseException {
    // create a new object to update
    DatabaseDriverAndroid updateDatabase = new DatabaseDriverAndroid(activityContext);
    // create a select helper to validate inputs
    DatabaseSelectHelperAndroid helper = new DatabaseSelectHelperAndroid(activityContext);
    // make result boolean
    boolean result = false;
    try {
      // validate inputs
      if (!(password.isEmpty() || id <= 0 || helper.getUserDetails(id) == null)) {
        result = updateDatabase.updateUserPassword(password, id);
      }
    } catch (UserIdNotInDatabaseException e) {
      throw new UserIdNotInDatabaseException();
    } finally {
      // close the db object after use
      updateDatabase.close();
      // return if update was successful
      return result;
    }
  }

  /**
   * validates if inputs are correct then updates the db with inputs.
   *
   * @param roleId id of a role in the db
   * @param id of user
   * @return true if update was succesful false otherwise
   * @throws UserIdNotInDatabaseException thrown when the id does not exist in db
   */
  public boolean updateUserRole(int roleId, int id) throws UserIdNotInDatabaseException {
    // create a new object to update
    DatabaseDriverAndroid updateDatabase = new DatabaseDriverAndroid(activityContext);
    // create a select helper to validate inputs
    DatabaseSelectHelperAndroid helper = new DatabaseSelectHelperAndroid(activityContext);
    // make result boolean
    boolean result = false;
    try {
      // validate inputs
      if (!(roleId <= 0 || id <= 0 || helper.getUserDetails(id) == null)) {
        result = updateDatabase.updateUserRole(roleId, id);
      }
    } catch (UserIdNotInDatabaseException e) {
      throw new UserIdNotInDatabaseException();
    } finally {
      // close the db object after use
      updateDatabase.close();
      // return if update was successful
      return result;
    }
  }

}
