package com.b07.exceptions;

public class SalesIdNotInDatabaseException extends Exception {

  private static final long serialVersionUID = -5862950495941780983L;

  public SalesIdNotInDatabaseException() {
  }

  public SalesIdNotInDatabaseException(String message) {
    super(message);
  }

  public SalesIdNotInDatabaseException(Throwable cause) {
    super(cause);
  }

  public SalesIdNotInDatabaseException(String message, Throwable cause) {
    super(message, cause);
  }

  public SalesIdNotInDatabaseException(String message, Throwable cause, boolean enableSuppression,
      boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }

}
