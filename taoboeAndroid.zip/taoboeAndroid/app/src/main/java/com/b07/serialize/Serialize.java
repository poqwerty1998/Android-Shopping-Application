package com.b07.serialize;

import android.content.Context;
import com.b07.exceptions.AccountNotInDatabaseException;
import com.b07.exceptions.ItemIdNotInDatabaseException;
import com.b07.exceptions.RoleIdNotInDatabaseException;
import com.b07.exceptions.SalesIdNotInDatabaseException;
import com.b07.exceptions.UserIdNotInDatabaseException;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.sql.SQLException;

public class Serialize {

  private transient Context context;

  public Serialize(Context context) {
    this.context = context;
  }

  public void serialize() throws SQLException, RoleIdNotInDatabaseException,
      UserIdNotInDatabaseException, ItemIdNotInDatabaseException, SalesIdNotInDatabaseException,
      AccountNotInDatabaseException {
    SerializeDatabase serializeDatabase = new SerializeDatabase(this.context);
    //set everything in the db;
    serializeDatabase.setAccount();
    serializeDatabase.setAccountSummary();
    serializeDatabase.setInventory();
    serializeDatabase.setItemizedSales();
    serializeDatabase.setItems();
    serializeDatabase.setRoles();
    serializeDatabase.setUserRole();
    serializeDatabase.setUsers();
    serializeDatabase.setSales();
    serializeDatabase.setUserPassword();
    serializeDatabase.setUsers();
    try {

      // make a new serialize db obj
      // set all tables and data using set methods
      // get the db class then make the serialize file
      FileOutputStream fileOut =
          new FileOutputStream("/data/app/taoboe/database_copy.ser");
      ObjectOutputStream out = new ObjectOutputStream(fileOut);
      // write out the serialize database
      out.writeObject(serializeDatabase);
      out.close();
      fileOut.close();
      //Toast this
      //System.out.println("Serialized data is saved in ./app/src/main/java/com/b07/database_copy.ser");
    } catch (IOException i) {
      i.printStackTrace();
    }
  }
}
