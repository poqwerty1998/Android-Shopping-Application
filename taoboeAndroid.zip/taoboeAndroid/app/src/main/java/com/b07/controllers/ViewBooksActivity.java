package com.b07.controllers;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ExpandableListView;
import android.widget.Toast;
import com.b07.adapters.ViewBooksExpandableListAdapter;
import com.b07.database.DatabaseSelectHelperAndroid;
import com.b07.exceptions.ItemIdNotInDatabaseException;
import com.b07.exceptions.RoleIdNotInDatabaseException;
import com.b07.exceptions.SalesIdNotInDatabaseException;
import com.b07.exceptions.UserIdNotInDatabaseException;
import com.b07.inventory.Item;
import com.b07.store.Sale;
import com.b07.store.SalesLog;
import com.b07.taoboe.R;
import com.b07.models.Roles;
import com.b07.models.User;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by User on 12/4/2017.
 */

public class ViewBooksActivity extends AppCompatActivity {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    Context context = this.getApplicationContext();
    // set content views
    setContentView(R.layout.display_view_books);

    // find my list view
    List<String> customerDetails = new ArrayList<String>();
    // make array lists to map the data
    HashMap<String, List<String>> viewBooksChild = new HashMap<String, List<String>>();
    ExpandableListView exListView = (ExpandableListView) findViewById(R.id.viewBooks);

    // instantize select helper to get values we need
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(context);
    SalesLog currentSales = null;
    try {
      currentSales = selectHelper.getSales();
    } catch (UserIdNotInDatabaseException e) {
      Toast.makeText(context,
          "Empty User Fields in database", Toast.LENGTH_SHORT).show();
    } catch (SalesIdNotInDatabaseException e) {
      Toast.makeText(context,
          "Empty Sales Fields in database", Toast.LENGTH_SHORT).show();
    }
    // check if there are any sales currently in the database
    if (currentSales.getSales().isEmpty()) {
      Toast.makeText(getApplicationContext(), "No entries in the db to show",
          Toast.LENGTH_SHORT).show();
    } else {

      // instantize variables we need in this method
      HashMap<Item, Integer> allItems = new HashMap<Item, Integer>();
      BigDecimal total = new BigDecimal(0);
      // store sales in a list
      List<Sale> salesList = currentSales.getSales();
      int counter = 0;
      for (int i = 0; i < salesList.size(); i++) {
        Sale sale = salesList.get(i);
        User user = sale.getUser();

        // check if user is a customer
        try {
          if (selectHelper.getRole(
              user.getRoleId()).equalsIgnoreCase(Roles.CUSTOMER.toString())) {
            total = total.add(sale.getTotalPrice());
            // add details into the list
            customerDetails.add("Customer: " + user.getName() +
                "\nPurchase Number:" + sale.getId() + "\nTotal: "
                + sale.getTotalPrice().toPlainString());
            List<String> temp = new ArrayList<String>();
            HashMap<Item, Integer> saleItemMap = sale.getItemMap();
            // get item map for sale if does not exist yet
            if (saleItemMap == null) {
              selectHelper.getItemizedSales(currentSales);
            }
            for (Item item : sale.getItemMap().keySet()) {
              temp.add(item.getName() + " : " + sale.getItemMap().get(item));
              if (allItems.containsKey(item)) {
                allItems.put(item, allItems.get(item) + sale.getItemMap().get(item));
              } else {
                allItems.put(item, sale.getItemMap().get(item));
              }

            }
            viewBooksChild.put(customerDetails.get(i), temp);
          }
        } catch (RoleIdNotInDatabaseException e) {
          Toast.makeText(context,
              "Empty Role Fields in database", Toast.LENGTH_SHORT).show();
        } catch (ItemIdNotInDatabaseException e) {
          Toast.makeText(context,
              "Empty Item Fields in database", Toast.LENGTH_SHORT).show();
        }

      }
      List<String> itemsSold = new ArrayList<String>();
      for (HashMap.Entry<Item, Integer> e : allItems.entrySet()) {
        itemsSold.add("Number " + e.getKey().getName() + " Sold: " + e.getValue());
      }
      // put total sales in customer details
      customerDetails.add("Total Sales: " + total.toPlainString());
      viewBooksChild.put(customerDetails.get(customerDetails.size() - 1), itemsSold);
      ViewBooksExpandableListAdapter adapterViewBooks =
          new ViewBooksExpandableListAdapter(this, customerDetails, viewBooksChild);
      exListView.setAdapter(adapterViewBooks);
    }


  }
}
