package com.b07.store;

import com.b07.inventory.Item;
import com.b07.models.User;
import java.math.BigDecimal;
import java.util.HashMap;

public interface Sale {

  /**
   * get the id of the sale.
   *
   * @return the id of the sale.
   */
  public int getId();

  /**
   * set the id of the sale.
   *
   * @param id of the sale.
   */
  public void setId(int id);

  /**
   * get the user of the sale.
   *
   * @return the user of the sale.
   */
  public User getUser();

  /**
   * set the user of the sale.
   *
   * @param user of the sale.
   */
  public void setUser(User user);

  /**
   * get the total price of the sale.
   *
   * @return id of the Sale.
   */
  public BigDecimal getTotalPrice();

  /**
   * sets the total price of the sale.
   *
   * @param price of the sale
   */
  public void setTotalPrice(BigDecimal price);

  /**
   * gets the ItemMap of the sale.
   *
   * @return the ItemMap of the sale.
   */
  public HashMap<Item, Integer> getItemMap();

  /**
   * sets the itemMap for the sale
   */
  public void setItemMap(HashMap<Item, Integer> itemMap);

}
