package com.b07.market;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.b07.database.DatabaseSelectHelperAndroid;
import com.b07.exceptions.UserIdNotInDatabaseException;
import com.b07.taoboe.R;
import com.b07.models.Customer;
import com.b07.models.Roles;

public class CustomerLoginActivity extends AppCompatActivity {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_user_login);
    TextView loginTitle = findViewById(R.id.login_title);
    loginTitle.setText("CUSTOMER LOGIN");

    Button customerSignIn = findViewById(R.id.signInButton);
    ImageButton backButton = findViewById(R.id.backButton);

    customerSignIn.setOnClickListener(buttonListener);
    backButton.setOnClickListener(buttonListener);

  }

  private View.OnClickListener buttonListener = new View.OnClickListener() {
    public void onClick(View v) {
      Intent nextIntent;
      EditText customerUserInput = findViewById(R.id.userInput);
      EditText customerPasswordInput = findViewById(R.id.passwordInput);

      switch (v.getId()) {
        case R.id.signInButton:
          Context context = getApplicationContext();
          if (customerUserInput.getText().toString().isEmpty()
              || customerPasswordInput.getText().toString().isEmpty()) {
            Toast.makeText(context, "Empty Fields", Toast.LENGTH_SHORT).show();
          } else {
            Integer userInput = Integer.valueOf(customerUserInput.getText().toString());
            String passwordInput = customerPasswordInput.getText().toString();
            //* need to put this into a private helper
            verify(context, userInput, passwordInput);
          }
          return;

        case R.id.backButton:
          nextIntent = new Intent(CustomerLoginActivity.this, MainActivity.class);
          startActivity(nextIntent);
          return;

      }

    }
  };

  private void verify(Context context, Integer userInput, String passwordInput) {
    Intent nextIntent;
    try {
      DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(context);
      Customer customer = (Customer) selectHelper.getUserDetails(userInput);
      boolean result = customer.authenticate(passwordInput);
      String role = selectHelper.getRole(selectHelper.getUserRole(userInput));
      if (result && role.equalsIgnoreCase(Roles.CUSTOMER.toString())) {
        nextIntent = new Intent(CustomerLoginActivity.this, CustomerInterfaceActivity.class);

        nextIntent.putExtra("customerUserId", customer.getId());
        nextIntent.putExtra("customerName", customer.getName());
        startActivity(nextIntent);
      } else if (!result) {
        Toast.makeText(context, "Invalid password", Toast.LENGTH_SHORT).show();
      } else if (!role.equalsIgnoreCase(Roles.CUSTOMER.toString())) {
        Toast.makeText(context, "Not customer account", Toast.LENGTH_SHORT).show();
      }
    } catch (UserIdNotInDatabaseException e) {
      Toast.makeText(context, "User not in store", Toast.LENGTH_SHORT).show();
    } catch (Exception e) {
      Toast.makeText(context, "Invalid user name or password", Toast.LENGTH_SHORT).show();
    }
  }

  ;
}
