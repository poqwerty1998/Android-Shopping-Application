package com.b07.factory;

import android.content.Context;
import com.b07.database.DatabaseInsertHelperAndroid;
import com.b07.database.DatabaseSelectHelperAndroid;
import com.b07.exceptions.RoleIdNotInDatabaseException;
import com.b07.exceptions.UserIdNotInDatabaseException;
import com.b07.models.Roles;

public class CreateAccountImpl implements CreateAccount {

  private int userId;
  private Context context;

  public CreateAccountImpl(int userId, Context context) {
    this.userId = userId;
    this.context = context;
  }

  @Override
  public boolean createCustomerAccount(int userId, Context context) {
    DatabaseInsertHelperAndroid insertHelper = new DatabaseInsertHelperAndroid(context);
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(context);
    try {
      // check if the user is in the database
      if (selectHelper.getUsersByRole(selectHelper.getRoleIdFromRoleName(
          Roles.CUSTOMER.toString())).contains(userId)) {
        int roleId = selectHelper.getUserRole(userId);

        // check if the user is a customer
        if (selectHelper.getRole(roleId).equalsIgnoreCase(Roles.CUSTOMER.toString())) {
          // create the account
          insertHelper.insertAccount(userId, true);
          return true;
        }
      }
      // if any exception was raised, account is not created and returns false
    } catch (RoleIdNotInDatabaseException | UserIdNotInDatabaseException e) {
      return false;
    }
    return false;
  }
}
