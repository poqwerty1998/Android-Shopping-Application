package com.b07.exceptions;

public class SalesNotInDatabaseException extends Exception {

  private static final long serialVersionUID = -5862950495941780983L;

  public SalesNotInDatabaseException() {
  }

  public SalesNotInDatabaseException(String message) {
    super(message);
  }

  public SalesNotInDatabaseException(Throwable cause) {
    super(cause);
  }

  public SalesNotInDatabaseException(String message, Throwable cause) {
    super(message, cause);
  }

  public SalesNotInDatabaseException(String message, Throwable cause, boolean enableSuppression,
      boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }

}
