package com.b07.serialize;

import android.content.Context;
import com.b07.database.DatabaseSelectHelperAndroid;
import com.b07.exceptions.AccountNotInDatabaseException;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import com.b07.exceptions.ItemIdNotInDatabaseException;
import com.b07.exceptions.RoleIdNotInDatabaseException;
import com.b07.exceptions.SalesIdNotInDatabaseException;
import com.b07.exceptions.UserIdNotInDatabaseException;

import com.b07.inventory.Item;
import com.b07.store.Sale;
import com.b07.store.SalesLog;
import com.b07.models.User;

public class SerializeDatabase implements Serializable {

  private static final long serialVersionUID = -1131141467469910933L;
  private transient Context context;
  // USERPW
  private HashMap<Integer, String> userPassword;
  // salesId -> HashMap<Item, quantity>
  private HashMap<Integer, HashMap<Item, Integer>> itemizedSales;
  // SALES
  private List<Sale> sales;
  // USERS
  private List<User> users;
  // roleId -> userId USERROLE
  private HashMap<Integer, List<Integer>> userRole;
  // Item yeet ITEMS
  private List<Item> items;
  // accountId -> HashMap<itemId, quantity> yeet
  private HashMap<Integer, HashMap<Integer, Integer>> accountSummary;
  // userId -> HashMap<accountId, status> Account
  private HashMap<Integer, HashMap<Integer, Boolean>> account;
  // roleId -> name yeet ROLES
  private HashMap<Integer, String> roles;
  // Inventory Yeet
  private HashMap<Item, Integer> inventory;

  /**
   *
   */
  public SerializeDatabase(Context context) {
    this.context = context;
  }

  /**
   * returns user and password table in database with HashMap representation
   *
   * @return HashMap<Integer, String> userId -> password
   */
  public HashMap<Integer, String> getUserPassword() {
    return this.userPassword;
  }

  /**
   * returns users table in database with HashMap representation
   *
   * @return HashMap<Integer, User> userId -> User object
   */
  public List<User> getUsers() {
    return this.users;
  }

  /**
   * returns user and roles table in database with HashMap representation
   *
   * @return HashMap<Integer, List<Integer>> roleId -> List(int userId)
   */
  public HashMap<Integer, List<Integer>> getUserRole() {
    return this.userRole;
  }

  /**
   * returns roles table in database with HashMap representation
   *
   * @return HashMap<Integer, String> roleId -> List(String name)
   */
  public HashMap<Integer, String> getRoles() {
    return this.roles;
  }

  public List<Sale> getSales() {
    return this.sales;
  }

  public HashMap<Integer, HashMap<Item, Integer>> getItemizedSales() {
    return this.itemizedSales;
  }

  public List<Item> getItems() {
    return this.items;
  }

  public HashMap<Item, Integer> getInventory() {
    return this.inventory;
  }

  public HashMap<Integer, HashMap<Integer, Integer>> getAccountSummary() {
    return this.accountSummary;
  }

  public HashMap<Integer, HashMap<Integer, Boolean>> getAccount() {
    return this.account;
  }

  // create new helper
  public void setUserPassword()
      throws SQLException, UserIdNotInDatabaseException, RoleIdNotInDatabaseException {
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(this.context);
    HashMap<Integer, String> userPasswordMap = new HashMap<Integer, String>();
    String password = "";
    for (int userId : selectHelper.getUserIds()) {
      password = selectHelper.getPassword(userId);
      userPasswordMap.put(userId, password);
    }
    this.userPassword = userPasswordMap;
  }

  // ok
  public void setUsers()
      throws SQLException, RoleIdNotInDatabaseException, UserIdNotInDatabaseException {
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(this.context);
    List<User> users = new ArrayList<>();
    for (User user : selectHelper.getUsersDetails()) {
      users.add(user);
    }
    this.users = users;
  }

  // create helper or get user Roles by role id from database
  public void setUserRole()
      throws SQLException, UserIdNotInDatabaseException, RoleIdNotInDatabaseException {
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(this.context);
    HashMap<Integer, List<Integer>> map = new HashMap<Integer, List<Integer>>();
    int roleId = -1;
    for (User user : selectHelper.getUsersDetails()) {
      int userId = user.getId();
      roleId = selectHelper.getUserRole(userId);
      if (map.containsKey(roleId)) {
        map.get(roleId).add(userId);
      } else {
        List<Integer> userIds = new ArrayList<Integer>();
        userIds.add(userId);
        map.put(roleId, userIds);
      }
    }
    this.userRole = map;
  }

  public void setRoles() throws SQLException, RoleIdNotInDatabaseException {
    HashMap<Integer, String> map = new HashMap<Integer, String>();
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(this.context);
    for (int roleId : selectHelper.getRoles()) {
      String name = selectHelper.getRole(roleId);
      map.put(roleId, name);
    }
    this.roles = map;
  }

  // ok get only sales instead
  public void setSales() throws SQLException, RoleIdNotInDatabaseException,
      UserIdNotInDatabaseException, ItemIdNotInDatabaseException, SalesIdNotInDatabaseException {
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(this.context);
    HashMap<Integer, Sale> map = new HashMap<Integer, Sale>();
    SalesLog allSales = selectHelper.getSales();
    this.sales = allSales.getSales();
  }

  public void setItemizedSales() throws SQLException, RoleIdNotInDatabaseException,
      UserIdNotInDatabaseException, ItemIdNotInDatabaseException, SalesIdNotInDatabaseException {
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(this.context);
    HashMap<Integer, HashMap<Item, Integer>> map = new HashMap<Integer, HashMap<Item, Integer>>();
    SalesLog allSales = selectHelper.getSales();
    selectHelper.getItemizedSales(allSales);
    List<Sale> sales = allSales.getSales();
    for (Sale sale : sales) {
      map.put(sale.getId(), sale.getItemMap());
    }
    this.itemizedSales = map;

  }

  // set only items
  public void setItems() throws SQLException, ItemIdNotInDatabaseException {
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(this.context);
    HashMap<Integer, Item> map = new HashMap<Integer, Item>();
    this.items = selectHelper.getAllItems();
  }

  //ok
  public void setInventory() throws ItemIdNotInDatabaseException {
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(this.context);
    this.inventory = selectHelper.getInventory().getItemMap();
  }

  public void setAccountSummary() throws UserIdNotInDatabaseException,
      AccountNotInDatabaseException {
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(this.context);
    HashMap<Integer, HashMap<Integer, Integer>> map =
        new HashMap<Integer, HashMap<Integer, Integer>>();
    for (int userId : selectHelper.getUserIds()) {
      for (int accountId : selectHelper.getUserAccounts(userId)) {
        map.put(accountId, selectHelper.getAccountDetails(accountId));
      }
    }
    this.accountSummary = map;
  }

  public void setAccount() throws SQLException, UserIdNotInDatabaseException {
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(this.context);
    HashMap<Integer, HashMap<Integer, Boolean>> map = new HashMap<>();
    for (int userId : selectHelper.getUserIds()) {
      for (int accountId : selectHelper.getUserActiveAccounts(userId)) {
        HashMap<Integer, Boolean> details = new HashMap<>();
        details.put(accountId, true);
        map.put(userId, details);
      }
      for (int accountId : selectHelper.getUserInactiveAccounts(userId)) {
        HashMap<Integer, Boolean> details = new HashMap<>();
        details.put(accountId, false);
        map.put(userId, details);
      }
    }
    this.account = map;
  }

}
