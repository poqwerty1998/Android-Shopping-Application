package com.b07.models;

import android.content.Context;

import com.b07.database.DatabaseSelectHelperAndroid;
import com.b07.exceptions.RoleIdNotInDatabaseException;
import java.sql.SQLException;

public class Admin extends User {

  /**
   * This will initialize the Admin object when created.
   *
   * @param id the userId of user.
   * @param name the name of the user.
   * @param age the age of the user in integer.
   * @param address the address of the user that is less than or equal to 100 chars.
   * @throws SQLException on database failures.
   * @throws RoleIdNotInDatabaseException on role no in database failures.
   */

  public Admin(int id, String name, int age, String address, Context context)
      throws SQLException, RoleIdNotInDatabaseException {
    super(id, name, age, address, -1, context);
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(context);
    super.setRoleId(selectHelper.getRoleIdFromRoleName(Roles.ADMIN.toString()));
  }

  /**
   * This will initialize the Admin object when created with authenticated value.
   *
   * @param id the userId of user.
   * @param name the name of the user.
   * @param age the age of the user in integer.
   * @param address the address of the user that is less than or equal to 100 chars.
   * @param authenticated if the user is authenticated in the system.
   * @throws SQLException on database failures.
   * @throws RoleIdNotInDatabaseException on role no in database failures.
   */

  public Admin(int id, String name, int age, String address, boolean authenticated,
      Context context) throws SQLException, RoleIdNotInDatabaseException {
    super(id, name, age, address, -1, authenticated, context);
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(context);
    super.setRoleId(selectHelper.getRoleIdFromRoleName(Roles.ADMIN.toString()));
  }
}
