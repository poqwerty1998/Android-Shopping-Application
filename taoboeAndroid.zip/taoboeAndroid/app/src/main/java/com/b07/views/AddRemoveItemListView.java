package com.b07.views;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.b07.database.DatabaseSelectHelperAndroid;
import com.b07.exceptions.ItemIdNotInDatabaseException;
import com.b07.inventory.Item;
import com.b07.market.CustomerInterfaceActivity;
import com.b07.taoboe.R;

import java.util.ArrayList;


/**
 * Created by apple on 2017/12/3.
 */

public class AddRemoveItemListView extends AppCompatActivity {

  private ListView itemListView;
  private ArrayAdapter<String> adapter;
  private ArrayList<String> itemInfo;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.listview_add_remove_item);
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(
        getApplicationContext());

    this.itemInfo = getIntent().getExtras().getStringArrayList("itemInfo");

    adapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1,
        itemInfo);
    itemListView = (ListView) findViewById(R.id.listItems);
    itemListView.setAdapter(adapter);

    Button add = findViewById(R.id.add);
    Button remove = findViewById(R.id.removeButton);
    add.setOnClickListener(buttonListener);
    remove.setOnClickListener(buttonListener);

  }


  private View.OnClickListener buttonListener = new View.OnClickListener() {
    public void onClick(View v) {
      //Intent nextIntent;
      switch (v.getId()) {
        case R.id.removeButton:
          removeDialog();
          return;
        case R.id.add:
          showAddDialog();
          return;
      }
    }
  };

  protected void showAddDialog() {
    LayoutInflater factory = LayoutInflater.from(this);
    final View textEntryView = factory.inflate(R.layout.customer_add_remove_item_dialog, null);
    final EditText editTextItemId = (EditText) textEntryView.findViewById(R.id.itemId);
    final EditText editTextItemQuantity = (EditText) textEntryView.findViewById(R.id.itemQuantity);

    AlertDialog.Builder ad1 = new AlertDialog.Builder(AddRemoveItemListView.this);
    ad1.setTitle("Add Item");
    ad1.setIcon(android.R.drawable.ic_dialog_info);
    ad1.setView(textEntryView);
    ad1.setPositiveButton("confirm", new DialogInterface.OnClickListener() {
      public void onClick(DialogInterface dialog, int i) {
        Intent nextIntent = new Intent();
        DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(
            getApplicationContext());
        try {

          int itemId = Integer.parseInt(editTextItemId.getText().toString());
          int quantity = Integer.parseInt(editTextItemQuantity.getText().toString());
          Item item = selectHelper.getItem(itemId);
          if (quantity > selectHelper.getInventoryQuantity(itemId)) {
            Toast.makeText(getApplicationContext(), "Quantity is not valid",
                Toast.LENGTH_SHORT).show();
          }

          nextIntent.putExtra("itemId", itemId);
          nextIntent.putExtra("quantity", quantity);
          nextIntent.putExtra("action", true);
          setResult(Activity.RESULT_OK, nextIntent);
          finish();
        } catch (ItemIdNotInDatabaseException e) {
          Toast.makeText(getApplicationContext(), "item id does not exist",
              Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
          Toast.makeText(getApplicationContext(), "Item not added",
              Toast.LENGTH_SHORT).show();
        }

      }
    });
    ad1.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
      public void onClick(DialogInterface dialog, int i) {
      }
    });
    ad1.show();
  }

  protected void removeDialog() {
    LayoutInflater factory = LayoutInflater.from(this);
    final View textEntryView = factory.inflate(R.layout.customer_add_remove_item_dialog, null);
    final EditText editTextItemId = (EditText) textEntryView.findViewById(R.id.itemId);
    final EditText editTextItemQuantity = (EditText) textEntryView.findViewById(R.id.itemQuantity);

    AlertDialog.Builder ad1 = new AlertDialog.Builder(AddRemoveItemListView.this);
    ad1.setTitle("Remove Item");
    ad1.setIcon(android.R.drawable.ic_dialog_info);
    ad1.setView(textEntryView);
    ad1.setPositiveButton("confirm", new DialogInterface.OnClickListener() {
      public void onClick(DialogInterface dialog, int i) {
        Intent nextIntent = new Intent();
        DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(
            getApplicationContext());
        try {
          int itemId = Integer.parseInt(editTextItemId.getText().toString());
          int quantity = Integer.parseInt(editTextItemQuantity.getText().toString());

          Item item = selectHelper.getItem(itemId);
          nextIntent.putExtra("itemId", itemId);
          nextIntent.putExtra("quantity", quantity);
          nextIntent.putExtra("action", false);

          setResult(Activity.RESULT_OK, nextIntent);
          finish();
        } catch (ItemIdNotInDatabaseException e) {
          Toast.makeText(getApplicationContext(), "item id does not exist",
              Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
          Toast.makeText(getApplicationContext(), "Item not removed",
              Toast.LENGTH_SHORT).show();
        }

      }
    });
    ad1.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
      public void onClick(DialogInterface dialog, int i) {
      }
    });
    ad1.show();
  }

//  @Override
//  public void onBackPressed() {
//
//  }

}