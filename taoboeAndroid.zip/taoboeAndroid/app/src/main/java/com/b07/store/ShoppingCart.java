package com.b07.store;

import android.content.Context;
import com.b07.database.DatabaseInsertHelperAndroid;
import com.b07.database.DatabaseSelectHelperAndroid;
import com.b07.database.DatabaseUpdateHelperAndroid;
import com.b07.exceptions.DatabaseInsertException;
import com.b07.exceptions.EmptyCartException;
import com.b07.exceptions.InsufficientStockException;
import com.b07.exceptions.InvalidQuantityException;
import com.b07.exceptions.ItemIdNotInDatabaseException;
import com.b07.exceptions.RoleIdNotInDatabaseException;
import com.b07.exceptions.SalesIdNotInDatabaseException;
import com.b07.exceptions.UserIdNotInDatabaseException;
import com.b07.inventory.Item;
import com.b07.models.Customer;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

public class ShoppingCart {

  private HashMap<Item, Integer> items = new HashMap<Item, Integer>();
  private Customer customer;
  private BigDecimal total = BigDecimal.ZERO;
  static final BigDecimal TAXRATE = new BigDecimal("1.13");
  private Context context;


  public ShoppingCart(Customer customer, Context context) {
    this.customer = customer;
    this.context = context;
  }

  /**
   * This method adds an item to the shopping cart.
   *
   * @param item is the item that is being added.
   * @param quantity is the amount of an item
   * @throws DatabaseInsertException thrown when insert fails
   * @throws SQLException thrown when sql runs into errors
   */
  public void addItem(Item item, int quantity)
      throws DatabaseInsertException, SQLException, InsufficientStockException, ItemIdNotInDatabaseException, InvalidQuantityException {
    try {
      // check if the stock of the item in the store is sufficient for the addition to cart
      if (quantity > 0) {
        if (checkItemStock(item, quantity)) {
          if (containsItem(item)) {
            items.put(getItemFromId(item.getId()),
                this.items.get(getItemFromId(item.getId())) + quantity);
          } else {
            items.put(item, quantity);
          }
          BigDecimal price = item.getPrice().multiply(new BigDecimal(quantity));
          this.total = this.total.add(price);
        } else {
          throw new InsufficientStockException();
        }
      } else {
        throw new InvalidQuantityException();
      }
    } catch (InsufficientStockException e) {
      throw new InsufficientStockException();
    } catch (ItemIdNotInDatabaseException e) {
      throw new ItemIdNotInDatabaseException();
    }
  }

  /**
   * Removes an a certain amount of an item from a cart.
   *
   * @param item an item that is no longer needed
   * @param quantity amount of items to be removed
   * @throws DatabaseInsertException inserted when db cannot insert
   * @throws SQLException thrown when db runs into issues
   */
  public void removeItem(Item item, int quantity)
      throws DatabaseInsertException, SQLException, EmptyCartException, InvalidQuantityException {
    try {
      // if the quantity of the item that wants to be removed exceeds the existing amount in the
      // cart, or if the item doesn't exist
      Item compare = getItemFromId(item.getId());
      if (quantity <= 0) {
        throw new InvalidQuantityException();
      } else if (items.get(compare) - quantity < 0 | !items.containsKey(compare)) {
        throw new EmptyCartException();
      } else if (items.get(compare) - quantity >= 0) {
        items.put(compare, this.items.get(compare) - quantity);
        BigDecimal price = item.getPrice().multiply(new BigDecimal(quantity));
        this.total = this.total.subtract(price);
      }
    } catch (EmptyCartException e) {
      throw new EmptyCartException();
    }
  }

  public Item getItemFromId(int id) {
    Item item = null;
    for (Item i : this.items.keySet()) {
      if (i.getId() == id) {
        item = i;
      }
    }
    return item;
  }

  public boolean containsItem(Item item) {
    boolean contains = false;
    for (Item i : this.items.keySet()) {
      if (i.getId() == item.getId()) {
        contains = true;
      }
    }
    return contains;
  }

  public ArrayList<Integer> getItemId() {
    ArrayList<Integer> listId = new ArrayList<Integer>();
    for (Item i : this.items.keySet()) {
      listId.add(i.getId());
    }
    return listId;
  }

  public ArrayList<Integer> getQuantity() {
    ArrayList<Integer> quantity = new ArrayList<Integer>();
    for (Item i : this.items.keySet()) {
      quantity.add(this.items.get(i));
    }
    return quantity;
  }

  public HashMap<Item, Integer> getItemsAndQuantity() {
    return this.items;
  }

  public Customer getCustomer() {
    return this.customer;
  }

  public BigDecimal getTotal() {
    return this.total;
  }

  public BigDecimal getTaxRate() {
    return TAXRATE;
  }

  public void clearCart() {
    this.total = this.total.subtract(total);
    items.clear();
  }

  /**
   * This method checks out the entire shopping cart.
   *
   * @param shoppingCart is the shopping cart being checked out
   * @return true if the checkout was successful
   * @throws SQLException if something goes wrong.
   * @throws DatabaseInsertException if something goes wrong when inserting the sale into the
   * database.
   * @throws ItemIdNotInDatabaseException thrown when Id is not in db
   * @throws UserIdNotInDatabaseException thrown when Id is not in db
   * @throws RoleIdNotInDatabaseException thrown when Id is not in db
   */
  public boolean checkOut(ShoppingCart shoppingCart)
      throws SQLException, DatabaseInsertException, ItemIdNotInDatabaseException,
      RoleIdNotInDatabaseException, UserIdNotInDatabaseException, SalesIdNotInDatabaseException,
      InvalidQuantityException {
    DatabaseInsertHelperAndroid insertHelper = new DatabaseInsertHelperAndroid(context);
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(context);
    DatabaseUpdateHelperAndroid updateHelper = new DatabaseUpdateHelperAndroid(context);

    boolean result = true;
    int inventoryLeft = 1;
    // if the current shopping cart customer is the same as the customer of the shopping cart being
    // checked out
    if (this.getCustomer().getId() == shoppingCart.getCustomer().getId()) {

      // loop through the items in the shopping cart
      for (Entry<Item, Integer> entry : items.entrySet()) {
        Item item = entry.getKey();
        Integer quantity = entry.getValue();
        // if there is no stock left then can't check out
        if (!checkItemStock(item, quantity)) {
          result = false;
          return result;
        }
      }
      BigDecimal totalAfterTax = this.getTotal().multiply(this.getTaxRate());
      int saleId = -1;
      saleId = insertHelper.insertSale(this.getCustomer().getId(), totalAfterTax);
      for (Entry<Item, Integer> entry : items.entrySet()) {
        Item item = entry.getKey();
        Integer quantity = entry.getValue();
        // update the quantity in the database
        inventoryLeft = selectHelper.getInventoryQuantity(item.getId()) - quantity;
        updateHelper.updateInventoryQuantity(inventoryLeft, item.getId());
        insertHelper.insertItemizedSale(saleId, item.getId(), quantity);
      }
    } else {
      result = false;
    }

    return result;
  }

  /**
   * This method checks the database for an item and its quantity, return a boolean indicating if
   * the store has sufficient stock for the item and specified quantity.
   *
   * @param item is the item being checked.
   * @param quantity is the quantity of the item being checked.
   * @return true if there is sufficient stock for the specified quantity.
   * @throws ItemIdNotInDatabaseException if the item does not exist in the database.
   * @throws SQLException if something goes wrong.
   */
  public boolean checkItemStock(Item item, int quantity)
      throws SQLException, ItemIdNotInDatabaseException {
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(this.context);
    return selectHelper.getInventoryQuantity(item.getId()) >= quantity;
  }

  /**
   * This methods checks the database if this item is in stock.
   *
   * @param item is the item being checked
   * @return true if stock of the specified item > 0
   * @throws SQLException if something goes wrong.
   * @throws ItemIdNotInDatabaseException if the id of the item does not exist in the database.
   */
  public boolean checkItemStock(Item item) throws SQLException, ItemIdNotInDatabaseException {
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(this.context);
    return selectHelper.getInventoryQuantity(item.getId()) > 0;
  }

  public int getItemQuantity(Item item) {
    int result = 0;
    if (items.containsKey(item)) {
      result = items.get(item);
    }
    return result;
  }

}
