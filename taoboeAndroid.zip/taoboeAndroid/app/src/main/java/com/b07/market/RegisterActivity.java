package com.b07.market;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.b07.database.DatabaseInsertHelperAndroid;
import com.b07.database.DatabaseSelectHelperAndroid;
import com.b07.exceptions.RoleIdNotInDatabaseException;
import com.b07.exceptions.UserIdNotInDatabaseException;
import com.b07.taoboe.R;
import com.b07.models.Admin;
import com.b07.models.Roles;
import java.sql.SQLException;

public class RegisterActivity extends AppCompatActivity {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_user_login);
    TextView loginTitle = findViewById(R.id.login_title);
    loginTitle.setText("Admin log in");

    Button registerButton = findViewById(R.id.signInButton);
    ImageButton backButton = findViewById(R.id.backButton);
    registerButton.setOnClickListener(buttonListener);
    backButton.setOnClickListener(buttonListener);

    registerButton.setBackgroundResource(R.drawable.register_button);

    // use this for exceptions
    Toast.makeText(getApplicationContext(), "Log in as an admin to make an account",
        Toast.LENGTH_SHORT).show();
    // admin log in takes them to register customer activity
    //
  }

  private View.OnClickListener buttonListener = new View.OnClickListener() {
    public void onClick(View v) {
      Intent nextIntent;
      EditText registerUserInput = findViewById(R.id.userInput);
      EditText registerPasswordInput = findViewById(R.id.passwordInput);
      switch (v.getId()) {

        case R.id.signInButton:
          Context context = getApplicationContext();
          if (registerUserInput.getText().toString().isEmpty()
              || registerPasswordInput.getText().toString().isEmpty()) {
            Toast.makeText(context, "Empty Fields", Toast.LENGTH_SHORT).show();
          } else {
            int userInput = Integer.valueOf(registerUserInput.getText().toString());
            String passwordInput = registerPasswordInput.getText().toString();
            verify(context, userInput, passwordInput);
            finish();
          }
          return;
        case R.id.backButton:
          nextIntent = new Intent(RegisterActivity.this, MainActivity.class);
          startActivity(nextIntent);
          return;
      }

    }
  };

  private void verify(Context context, int userInput, String passwordInput) {
    Intent nextIntent;
    try {
      DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(context);
      DatabaseInsertHelperAndroid insertHelper = new DatabaseInsertHelperAndroid(context);
      Admin admin = (Admin) selectHelper.getUserDetails(userInput);
      boolean result = admin.authenticate(passwordInput);
      int userId = userInput;
      int roleId = selectHelper.getUserRole(userId);

      if (result && selectHelper.getRole(roleId).equalsIgnoreCase(Roles.ADMIN.toString())) {
        int accId = insertHelper.insertAccount(userId, true);
        Toast.makeText(getApplicationContext(), ("Your accId is " + accId), Toast.LENGTH_LONG)
            .show();
        finish();
      } else if (!result) {
        Toast.makeText(context, "Incorrect password", Toast.LENGTH_SHORT).show();
      } else {
        Toast.makeText(context, "Not an admin", Toast.LENGTH_SHORT).show();
      }
    } catch (UserIdNotInDatabaseException e) {
      Toast.makeText(context, "Admin not in db", Toast.LENGTH_SHORT).show();
    } catch (NumberFormatException e) {
      Toast.makeText(context, "Not a valid user id", Toast.LENGTH_SHORT).show();
    } catch (RoleIdNotInDatabaseException e) {
      Toast.makeText(context, "Something went wrong with the admin role",
          Toast.LENGTH_SHORT).show();
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }

}
