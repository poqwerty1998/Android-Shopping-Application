package com.b07.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;
import com.b07.database.DatabaseSelectHelperAndroid;
import com.b07.taoboe.R;
import java.util.ArrayList;

/**
 * Created by Qi on 12/3/2017.
 */

public class AccountAdapter extends ArrayAdapter<Integer> {
  public AccountAdapter(Context context, ArrayList<Integer> data) {
    super(context, R.layout.custom_card_account, data);
  }

  @Override
  public View getView(int position, View convertView, ViewGroup parent) {
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(this.getContext());
    LayoutInflater myCustomInflater = LayoutInflater.from(this.getContext());
    View customView = myCustomInflater.inflate(R.layout.custom_card_account, parent, false);
    // get references.

    TextView accountId = (TextView) customView.findViewById(R.id.accountId);

    try {
      accountId.setText("account ID : " + getItem(position));
    } catch (Exception e) {
      Toast.makeText(getContext(),"some exception", Toast.LENGTH_SHORT).show();
    }
    return customView;
  }
}
