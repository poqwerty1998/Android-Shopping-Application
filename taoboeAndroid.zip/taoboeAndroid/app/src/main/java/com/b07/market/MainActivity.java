package com.b07.market;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import android.view.View;


import com.b07.database.DatabaseInsertHelperAndroid;
import com.b07.database.DatabaseSelectHelperAndroid;
import com.b07.exceptions.UserIdNotInDatabaseException;
import com.b07.factory.UserCreation;
import com.b07.taoboe.R;
import java.math.BigDecimal;

public class MainActivity extends AppCompatActivity {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    Button adminLoginButton = findViewById(R.id.admin_login_button);
    Button customerLoginButton = findViewById(R.id.customer_login_button);
    adminLoginButton.setOnClickListener(buttonListener);
    customerLoginButton.setOnClickListener(buttonListener);

  }

  private View.OnClickListener buttonListener = new View.OnClickListener() {
    public void onClick(View v) {
      Intent nextIntent;
      switch (v.getId()) {
        case R.id.customer_login_button:
          nextIntent = new Intent(MainActivity.this,
              CustomerLoginActivity.class);
          startActivity(nextIntent);
          return;

        case R.id.admin_login_button:

          nextIntent = new Intent(MainActivity.this,
              AdminLoginActivity.class);
          startActivity(nextIntent);
          return;
      }
    }
  };

  @Override
  public void onBackPressed() {
  }


}
