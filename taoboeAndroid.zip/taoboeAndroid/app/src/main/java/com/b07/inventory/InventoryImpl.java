package com.b07.inventory;

import java.util.HashMap;

/**
 * this class implements inventory and makes getter and setters.
 */
public class InventoryImpl implements Inventory {

  private HashMap<Item, Integer> itemMap;
  private int totalItems;

  /**
   * Constructor for this class, needs a hash map of item and its quantity
   * also needs a total value for items.
   */
  public InventoryImpl(HashMap<Item, Integer> itemMap, int totalItems) {
    this.itemMap = itemMap;
    this.totalItems = totalItems;
  }

  @Override
  public HashMap<Item, Integer> getItemMap() {
    return this.itemMap;
  }

  @Override
  public void setItemMap(HashMap<Item, Integer> itemMap) {
    this.itemMap = itemMap;
  }

  @Override
  public void updateMap(Item item, Integer value) {
    itemMap.put(item, value);
  }

  @Override
  public int getTotalItems() {
    return this.totalItems;
  }

  @Override
  public void setTotalItems(int total) {
    this.totalItems = total;
  }

}
