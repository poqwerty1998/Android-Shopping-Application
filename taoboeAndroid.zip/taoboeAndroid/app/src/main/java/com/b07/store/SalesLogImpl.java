package com.b07.store;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class SalesLogImpl implements SalesLog {

  private List<Sale> saleLog;
  private int totalSales;
  private BigDecimal totalPrice;

  /**
   * This is the blank constructor for the SalesLogImpl - initializes empty or base values of zero.
   */
  public SalesLogImpl() {
    this.saleLog = new ArrayList<Sale>();
    this.totalSales = 0;
    this.totalPrice = new BigDecimal(0);
  }

  @Override
  public void addSale(Sale sale) {
    this.saleLog.add(sale);
  }

  @Override
  public List<Sale> getSales() {
    return this.saleLog;
  }

  @Override
  public int getTotalSales() {
    return this.totalSales;
  }

  @Override
  public void setTotalSales(int totalSales) {
    this.totalSales = totalSales;
  }

  @Override
  public BigDecimal getTotalPrice() {
    return this.totalPrice;
  }

  @Override
  public void setTotalPrice(BigDecimal totalPrice) {
    this.totalPrice = totalPrice;
  }

}
