package com.b07.exceptions;

public class RoleIdNotInDatabaseException extends Exception {

  private static final long serialVersionUID = -4319527419081968512L;

  public RoleIdNotInDatabaseException() {
  }

  public RoleIdNotInDatabaseException(String message) {
    super(message);
  }

  public RoleIdNotInDatabaseException(Throwable cause) {
    super(cause);
  }

  public RoleIdNotInDatabaseException(String message, Throwable cause) {
    super(message, cause);
  }

  public RoleIdNotInDatabaseException(String message, Throwable cause, boolean enableSuppression,
      boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }

}
