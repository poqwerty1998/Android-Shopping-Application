package com.b07.models;

public enum Roles {
  ADMIN, CUSTOMER;

  public static boolean containEnum(String role) {
    boolean contain = false;
    if (role.equalsIgnoreCase(ADMIN.toString())) {
      contain = true;
    } else if (role.equalsIgnoreCase(CUSTOMER.toString())) {
      contain = true;
    }
    return contain;
  }
}
