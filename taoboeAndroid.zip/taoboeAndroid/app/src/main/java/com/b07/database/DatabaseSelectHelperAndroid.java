package com.b07.database;

import android.content.Context;
import android.database.Cursor;

import com.b07.exceptions.AccountNotInDatabaseException;
import com.b07.exceptions.ItemIdNotInDatabaseException;
import com.b07.exceptions.RoleIdNotInDatabaseException;
import com.b07.exceptions.SalesIdNotInDatabaseException;
import com.b07.exceptions.UserIdNotInDatabaseException;
import com.b07.inventory.Inventory;
import com.b07.inventory.InventoryImpl;
import com.b07.inventory.Item;
import com.b07.inventory.ItemImpl;
import com.b07.store.Sale;
import com.b07.store.SaleImpl;
import com.b07.store.SalesLog;
import com.b07.store.SalesLogImpl;

import com.b07.models.Admin;
import com.b07.models.Customer;
import com.b07.models.Roles;
import com.b07.models.User;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class DatabaseSelectHelperAndroid {

  private Context context;

  public DatabaseSelectHelperAndroid(Context context) {
    this.context = context;

  }

  public int getRoleIdFromRoleName(String name) throws RoleIdNotInDatabaseException {
    List<Integer> roleIds = this.getRoles();
    int roleId = -1;
    for (int i : roleIds) {
      if (this.getRole(i).equalsIgnoreCase(name)) {
        roleId = i;
      }
    }
    return roleId;
  }

  /**
   * get all the roles from roles table and add their id into a list of integers.
   *
   * @return a list of Role Ids
   */
  public List<Integer> getRoles() {
    DatabaseDriverAndroid selectDatabase = new DatabaseDriverAndroid(context);
    Cursor cursorSet = selectDatabase.getRoles();
    List<Integer> roleIds = new ArrayList<>();
    while (cursorSet.moveToNext()) {
      roleIds.add(cursorSet.getInt(cursorSet.getColumnIndex("ID")));
    }
    cursorSet.close();
    selectDatabase.close();
    return roleIds;
  }

  /**
   * Get the name of a specific role .
   *
   * @param roleId integer value
   * @return the name of the role
   * @throws RoleIdNotInDatabaseException id wanted is invalid or doesn't exist in the database
   */
  public String getRole(int roleId) throws RoleIdNotInDatabaseException {
    DatabaseDriverAndroid selectDatabase = new DatabaseDriverAndroid(context);
    try {
      String roleName = selectDatabase.getRole(roleId);
      selectDatabase.close();
      return roleName;
    } catch (Exception e) {
      selectDatabase.close();
      throw new RoleIdNotInDatabaseException();
    }
  }

  /**
   * Get the id of a specific role.
   *
   * @param userId integer value
   * @return the id of the role
   * @throws UserIdNotInDatabaseException id wanted is invalid or doesn't exist in the database
   */
  public int getUserRole(int userId) throws UserIdNotInDatabaseException {
    DatabaseDriverAndroid selectDatabase = new DatabaseDriverAndroid(context);
    try {
      int id = selectDatabase.getUserRole(userId);
      selectDatabase.close();
      return id;
    } catch (Exception e) {
      selectDatabase.close();
      throw new UserIdNotInDatabaseException();
    }
  }

  /**
   * Get a list of all userIds from the wanted role.
   *
   * @param roleId integer
   * @return list of all user Ids
   * @throws RoleIdNotInDatabaseException id wanted is invalid or doesn't exist in the database
   */
  public List<Integer> getUsersByRole(int roleId) throws RoleIdNotInDatabaseException {
    DatabaseDriverAndroid selectDatabase = new DatabaseDriverAndroid(context);
    try {
      List<Integer> userIdsByRole = new ArrayList<>();
      Cursor cursorSet = selectDatabase.getUsersByRole(roleId);
      while (cursorSet.moveToNext()) {
        userIdsByRole.add(cursorSet.getInt(cursorSet.getColumnIndex("USERID")));
      }
      cursorSet.close();
      selectDatabase.close();
      return userIdsByRole;
    } catch (Exception e) {
      selectDatabase.close();
      throw new RoleIdNotInDatabaseException();
    }
  }

  /**
   * Get a list of all users.
   *
   * @return a list of all users.
   * @throws UserIdNotInDatabaseException id wanted is invalid or doesn't exist in the database
   */
  public List<User> getUsersDetails() throws UserIdNotInDatabaseException {
    DatabaseDriverAndroid selectDatabase = new DatabaseDriverAndroid(context);
    Cursor cursorSet = selectDatabase.getUsersDetails();
    List<User> users = new ArrayList<>();
    while (cursorSet.moveToNext()) {
      User user = getUserDetails(cursorSet.getInt(cursorSet.getColumnIndex("ID")));
      users.add(user);
    }
    cursorSet.close();
    selectDatabase.close();
    return users;

  }

  /**
   * returns a user, and based on their role Id construct user with the proper role.
   *
   * @param userId integer value
   * @return the user
   * @throws UserIdNotInDatabaseException id wanted is invalid or doesn't exist in the database
   */
  public User getUserDetails(int userId) throws UserIdNotInDatabaseException {
    DatabaseDriverAndroid selectDatabase = new DatabaseDriverAndroid(context);
    try {
      Cursor cursorSet = selectDatabase.getUserDetails(userId);
      User user = null;
      cursorSet.moveToNext();
      if ((this.getRole(this.getUserRole(userId))).equals(Roles.CUSTOMER.toString())) {
        user = new Customer(cursorSet.getInt(cursorSet.getColumnIndex("ID")),
            cursorSet.getString(cursorSet.getColumnIndex("NAME")),
            cursorSet.getInt(cursorSet.getColumnIndex("AGE")),
            cursorSet.getString(cursorSet.getColumnIndex("ADDRESS")),
            context);
      } else if ((this.getRole(this.getUserRole(userId))).equals(Roles.ADMIN.toString())) {
        user = new Admin(cursorSet.getInt(cursorSet.getColumnIndex("ID")),
            cursorSet.getString(cursorSet.getColumnIndex("NAME")),
            cursorSet.getInt(cursorSet.getColumnIndex("AGE")),
            cursorSet.getString(cursorSet.getColumnIndex("ADDRESS")),
            context);
      } else {
        throw new UserIdNotInDatabaseException();
      }
      cursorSet.close();
      return user;
    } catch (Exception e) {
      selectDatabase.close();
      throw new UserIdNotInDatabaseException();
    }
  }

  /**
   * Get the pass word of the user Id in the database.
   *
   * @param userId integer value
   * @return the password in a string
   * @throws UserIdNotInDatabaseException id wanted is invalid or doesn't exist in the database
   */
  public String getPassword(int userId) throws UserIdNotInDatabaseException {
    DatabaseDriverAndroid selectDatabase = new DatabaseDriverAndroid(context);
    try {
      String userPassword = selectDatabase.getPassword(userId);
      selectDatabase.close();
      return userPassword;
    } catch (Exception e) {
      selectDatabase.close();
      throw new UserIdNotInDatabaseException();
    }
  }

  /**
   * returns a list of all items currently in database.
   *
   * @return a list of all items
   * @throws ItemIdNotInDatabaseException id wanted is invalid or doesn't exist in the database
   */
  public List<Item> getAllItems() throws ItemIdNotInDatabaseException {
    DatabaseDriverAndroid selectDatabase = new DatabaseDriverAndroid(context);
    Cursor cursorSet = selectDatabase.getAllItems();
    List<Item> items = new ArrayList<>();
    while (cursorSet.moveToNext()) {
      Item item = getItem(cursorSet.getInt(cursorSet.getColumnIndex("ID")));
      items.add(item);
    }
    cursorSet.close();
    selectDatabase.close();
    return items;
  }

  /**
   * Return the item with given Id, throws exception if id doesn't exist in database.
   *
   * @param itemId integer value
   * @return the item in an Item class
   * @throws ItemIdNotInDatabaseException id wanted is invalid or doesn't exist in the database
   */
  public Item getItem(int itemId) throws ItemIdNotInDatabaseException {
    DatabaseDriverAndroid selectDatabase = new DatabaseDriverAndroid(context);
    try {
      Cursor cursorSet = selectDatabase.getItem(itemId);
      cursorSet.moveToNext();
      Item item = new ItemImpl(cursorSet.getInt(cursorSet.getColumnIndex("ID")),
          cursorSet.getString(cursorSet.getColumnIndex("NAME")),
          new BigDecimal(cursorSet.getString(cursorSet.getColumnIndex("PRICE"))));
      cursorSet.close();
      selectDatabase.close();
      return item;
    } catch (Exception e) {
      selectDatabase.close();
      throw new ItemIdNotInDatabaseException();
    }
  }

  /**
   * Returns the inventory in an inventory object from the database.
   *
   * @return an populated inventory object
   * @throws ItemIdNotInDatabaseException id wanted is invalid or doesn't exist in the database
   */
  public Inventory getInventory() throws ItemIdNotInDatabaseException {
    DatabaseDriverAndroid selectDatabase = new DatabaseDriverAndroid(context);
    Cursor cursorSet = selectDatabase.getInventory();
    HashMap<Item, Integer> itemMap = new HashMap<Item, Integer>();
    int totalItems = 0;
    // get the item and construct them into the item map
    // add an item counter to return the total number of items
    while (cursorSet.moveToNext()) {
      itemMap.put(getItem(cursorSet.getInt(cursorSet.getColumnIndex("ITEMID"))),
          getInventoryQuantity(cursorSet.getInt(cursorSet.getColumnIndex("ITEMID"))));
      totalItems += getInventoryQuantity(cursorSet.getInt(
          cursorSet.getColumnIndex("ITEMID")));
    }
    Inventory inventory = new InventoryImpl(itemMap, totalItems);
    cursorSet.close();
    selectDatabase.close();
    return inventory;
  }

  /**
   * Gets the quantity of a specific item from inventory table in the database.
   *
   * @param itemId integer value
   * @return simple quantity integer
   * @throws ItemIdNotInDatabaseException id wanted is invalid or doesn't exist in the database
   */
  public int getInventoryQuantity(int itemId) throws ItemIdNotInDatabaseException {
    DatabaseDriverAndroid selectDatabase = new DatabaseDriverAndroid(context);
    try {
      int quantity = selectDatabase.getInventoryQuantity(itemId);
      selectDatabase.close();
      return quantity;
    } catch (Exception e) {
      selectDatabase.close();
      throw new ItemIdNotInDatabaseException();
    }
  }

  /**
   * Returns the inventory in an inventory object from the database.
   *
   * @return an populated inventory object
   * @throws ItemIdNotInDatabaseException id wanted is invalid or doesn't exist in the database
   */
  public SalesLog getSales() throws UserIdNotInDatabaseException, SalesIdNotInDatabaseException {
    DatabaseDriverAndroid selectDatabase = new DatabaseDriverAndroid(context);
    Cursor cursorSet = selectDatabase.getSales();
    SalesLog salesLog = new SalesLogImpl();
    int totalSales = 0;
    BigDecimal totalPrice = new BigDecimal("0");
    while (cursorSet.moveToNext()) {
      totalSales += 1;
      totalPrice = totalPrice.add(new BigDecimal(cursorSet.getString(cursorSet.getColumnIndex(
          "TOTALPRICE"))));
      // create a sale based off the saleId, userId, and the price of the sale
      // add the sale to the log
      salesLog.addSale(this.getSaleById(cursorSet.getInt(cursorSet.getColumnIndex(
          "ID"))));
    }
    salesLog.setTotalSales(totalSales);
    salesLog.setTotalPrice(totalPrice);
    cursorSet.close();
    selectDatabase.close();
    return salesLog;
  }

  /**
   * Given the id of a sale, return the sale associated with that saleId.
   *
   * @param saleId is the id of the sale
   * @return a sale
   */
  public Sale getSaleById(int saleId)
      throws UserIdNotInDatabaseException, SalesIdNotInDatabaseException {
    DatabaseDriverAndroid selectDatabase = new DatabaseDriverAndroid(context);
    Cursor cursorSet = selectDatabase.getSaleById(saleId);
    HashMap<Item, Integer> itemMap = null;
    cursorSet.moveToNext();
    Sale sale = new SaleImpl(cursorSet.getInt(cursorSet.getColumnIndex("ID")),
        this.getUserDetails(cursorSet.getInt(cursorSet.getColumnIndex("USERID"))),
        new BigDecimal(cursorSet.getString(cursorSet.getColumnIndex("TOTALPRICE"))),
        itemMap);
    cursorSet.close();
    selectDatabase.close();
    return sale;
  }

  /**
   * Given the id of a user, return a list of sales associated with that user.
   *
   * @param userId is the id of the user
   * @return a list of Sales objects associated with the userId
   */
  public List<Sale> getSalesToUser(int userId)
      throws UserIdNotInDatabaseException, SalesIdNotInDatabaseException {
    DatabaseDriverAndroid selectDatabase = new DatabaseDriverAndroid(context);
    Cursor cursorSet = selectDatabase.getSalesToUser(userId);
    List<Sale> sales = new ArrayList<>();
    while (cursorSet.moveToNext()) {
      Sale sale = this.getSaleById(cursorSet.getInt(cursorSet.getColumnIndex("ID")));
      sales.add(sale);
    }
    cursorSet.close();
    selectDatabase.close();
    return sales;
  }

  /**
   * Given a saleslog, get the itemized sales of the saleslog
   *
   * @param salesLog is a log of sales
   */
  public void getItemizedSales(SalesLog salesLog) throws ItemIdNotInDatabaseException {
    DatabaseDriverAndroid selectDatabase = new DatabaseDriverAndroid(context);
    Cursor cursorSet = selectDatabase.getItemizedSales();
    List<Sale> sales = salesLog.getSales();
    for (Sale sale : sales) {
      this.getItemizedSaleById(sale.getId(), sale);
    }
    cursorSet.close();
    selectDatabase.close();
  }

  /**
   * Given the sale id and the sale, get the itemized sale of the sale
   *
   * @param saleId is the id of the sale
   * @param sale is a sale
   * @return a list of Integer objects associated with the ids of the accounts
   */
  public void getItemizedSaleById(int saleId, Sale sale) throws ItemIdNotInDatabaseException {
    DatabaseDriverAndroid selectDatabase = new DatabaseDriverAndroid(context);
    Cursor cursorSet = selectDatabase.getItemizedSaleById(saleId);
    cursorSet.moveToNext();
    HashMap<Item, Integer> itemMap = new HashMap<Item, Integer>();
    itemMap.put(this.getItem(cursorSet.getInt(cursorSet.getColumnIndex("ITEMID"))),
        cursorSet.getInt(cursorSet.getColumnIndex("QUANTITY")));
    sale.setItemMap(itemMap);
    cursorSet.close();
    selectDatabase.close();
  }

  /**
   * Given the id of a user, return a list of account ids associated with that user.
   *
   * @param userId is the id of the user
   * @return a list of Integer objects associated with the ids of the accounts
   */
  public List<Integer> getUserAccounts(int userId) throws UserIdNotInDatabaseException {
    DatabaseDriverAndroid selectDatabase = new DatabaseDriverAndroid(context);
    List<Integer> userAccounts = new ArrayList<>();
    try {
      Cursor cursorSet = selectDatabase.getUserAccounts(userId);
      while (cursorSet.moveToNext()) {
        userAccounts.add(cursorSet.getInt(cursorSet.getColumnIndex("ID")));
      }
      cursorSet.close();
    } catch (Exception e) {
      throw new UserIdNotInDatabaseException();
    } finally {
      selectDatabase.close();
      return userAccounts;
    }
  }

  /**
   * Given the id of an account, return a Hashmap of the details of the account.
   *
   * @param accountId is the id of the account
   * @return Hashmap representation of the details of the account
   */

  public HashMap<Integer, Integer> getAccountDetails(int accountId)
      throws AccountNotInDatabaseException {
    DatabaseDriverAndroid selectDatabase = new DatabaseDriverAndroid(context);
    try {
      Cursor cursorSet = selectDatabase.getAccountDetails(accountId);
//      cursorSet.moveToNext();
      // hashmap to store the details of the item
      HashMap<Integer, Integer> accountItems = new HashMap<>();
      // loop through the values and add the item id as the key mapped to the quantity of the item
      while (cursorSet.moveToNext()) {
        accountItems.put(cursorSet.getInt(cursorSet.getColumnIndex("ITEMID")),
            cursorSet.getInt(cursorSet.getColumnIndex("QUANTITY")));
      }
      cursorSet.close();
      selectDatabase.close();
      return accountItems;
    } catch (Exception e) {
      selectDatabase.close();
      throw new AccountNotInDatabaseException();
    }
  }

  /**
   * Given the id of a user, return a list of all active account ids associated with this user.
   *
   * @param userId is the id of the user
   * @return list of accounts that are active
   */
  public List<Integer> getUserActiveAccounts(int userId) throws UserIdNotInDatabaseException {
    DatabaseDriverAndroid selectDatabase = new DatabaseDriverAndroid(context);
    List<Integer> activeAccounts = new ArrayList<>();
    try {
      Cursor cursorSet = selectDatabase.getUserActiveAccounts(userId);
      while (cursorSet.moveToNext()) {
        activeAccounts.add(cursorSet.getInt(cursorSet.getColumnIndex("ID")));
      }
      cursorSet.close();
    } catch (Exception e) {
      selectDatabase.close();
      throw new UserIdNotInDatabaseException();
    } finally {
      selectDatabase.close();
      return activeAccounts;

    }
  }

  /**
   * Given the id of a user, return a list of all inactive account ids associated with this user.
   *
   * @param userId is the id of the user
   * @return list of accounts that are active
   */
  public List<Integer> getUserInactiveAccounts(int userId) throws UserIdNotInDatabaseException {
    DatabaseDriverAndroid selectDatabase = new DatabaseDriverAndroid(context);
    List<Integer> inActiveAccounts = new ArrayList<>();
    try {
      Cursor cursorSet = selectDatabase.getUserInactiveAccounts(userId);
      while (cursorSet.moveToNext()) {
        inActiveAccounts.add(cursorSet.getInt(cursorSet.getColumnIndex("ID")));
      }
      cursorSet.close();
    } catch (Exception e) {
      throw new UserIdNotInDatabaseException();
    } finally {
      selectDatabase.close();
      return inActiveAccounts;
    }
  }

  //helper
  public List<Integer> getUserIds() throws UserIdNotInDatabaseException {
    List<User> userDetails = this.getUsersDetails();
    List<Integer> userIds = new ArrayList<>();
    for (User user : userDetails) {
      userIds.add(user.getId());
    }
    return userIds;
  }

}
