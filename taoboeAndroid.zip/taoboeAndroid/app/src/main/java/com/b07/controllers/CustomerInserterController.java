package com.b07.controllers;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.b07.database.DatabaseInsertHelperAndroid;
import com.b07.database.DatabaseSelectHelperAndroid;
import com.b07.market.MainActivity;
import com.b07.taoboe.R;

public class CustomerInserterController extends AppCompatActivity {

  private boolean firstRun;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.initialize_insert_user);
    this.firstRun = getIntent().getExtras().getBoolean("isFirstRun");
    Button createUserButton = findViewById(R.id.createUserButton);
    createUserButton.setOnClickListener(buttonListener);
    TextView title = findViewById(R.id.createUserTitleView);
    if (!firstRun) {
      title.setText("Please fill out the customer's information");
    } else {
      title.setText("Please fill out your first customer's information!");
    }
    ImageView imageCustomer = findViewById(R.id.createLogo);
    imageCustomer.setImageResource(R.drawable.ic_account_child);
  }

  private View.OnClickListener buttonListener = new View.OnClickListener() {
    public void onClick(View v) {
      Intent nextIntent;
      EditText inputName = findViewById(R.id.insertNameField);
      EditText inputAddress = findViewById(R.id.insertAddressField);
      EditText inputAge = findViewById(R.id.insertAgeField);
      EditText inputPassword = findViewById(R.id.insertPasswordField);

      switch (v.getId()) {
        case R.id.createUserButton:
          Context context = getApplicationContext();
          if (inputName.getText().toString().isEmpty()
              | inputAddress.getText().toString().isEmpty() |
              inputAge.getText().toString().isEmpty() |
              inputPassword.getText().toString().isEmpty()) {
            Toast.makeText(context, "Empty Fields", Toast.LENGTH_SHORT).show();
          } else {
            String nameInput = inputName.getText().toString();
            String addressInput = inputAddress.getText().toString();
            int ageInput = Integer.valueOf(inputAge.getText().toString());
            String passwordInput = inputPassword.getText().toString();

            try {
              DatabaseInsertHelperAndroid insertHelper = new DatabaseInsertHelperAndroid(
                  getApplicationContext());
              DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(
                  (getApplicationContext()));
              int customerRoleId = selectHelper.getRoleIdFromRoleName("CUSTOMER");
              if (firstRun) {

                int newCustomer = insertHelper
                    .insertNewUser(nameInput, ageInput, addressInput, passwordInput);
                insertHelper.insertUserRole(newCustomer, customerRoleId);
                Toast.makeText(getApplicationContext(), "Setup Complete! Customer ID: " +
                    newCustomer, Toast.LENGTH_SHORT).show();
                nextIntent = new Intent(CustomerInserterController.this,
                    MainActivity.class);

                startActivity(nextIntent);
                return;
              } else {
                int newCustomer = insertHelper
                    .insertNewUser(nameInput, ageInput, addressInput, passwordInput);
                Toast.makeText(getApplicationContext(), "Customer ID:" + newCustomer,
                    Toast.LENGTH_SHORT).show();
                insertHelper.insertUserRole(newCustomer, customerRoleId);
                finish();
                return;
              }

            } catch (Exception e) {
              Toast.makeText(context, "One of your inputs are invalid", Toast.LENGTH_SHORT).show();
            }
          }

          return;


      }
    }
  };
}
