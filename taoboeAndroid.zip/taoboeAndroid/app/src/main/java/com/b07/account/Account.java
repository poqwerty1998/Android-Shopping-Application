package com.b07.account;

public abstract class Account {

  protected int accId;
  protected int userId;

  // store user id and account id
  public Account(int accId, int userId) {
    this.accId = accId;
    this.userId = userId;
  }


  /**
   * This will get the id of the User
   *
   * @return id of the user
   */
  public int getUserId() {
    return this.userId;
  }

  /**
   * This will set the id of the User
   *
   * @param userId is the id of the user
   */
  public void setUserId(int userId) {
    this.userId = userId;
  }

  public int getAccId() {
    return this.accId;
  }

  public void setAccId(int accId) {
    this.accId = accId;
  }

}
