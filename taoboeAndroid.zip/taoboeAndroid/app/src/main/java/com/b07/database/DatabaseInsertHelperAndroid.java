package com.b07.database;

import android.content.Context;
import com.b07.exceptions.AccountNotInDatabaseException;
import com.b07.exceptions.InvalidPriceException;
import com.b07.exceptions.InvalidQuantityException;
import com.b07.exceptions.ItemIdNotInDatabaseException;
import com.b07.exceptions.ItemNameAlreadyInDatabaseException;
import com.b07.exceptions.ItemNotInDatabaseException;
import com.b07.exceptions.RoleIdNotInDatabaseException;
import com.b07.exceptions.SalesIdNotInDatabaseException;
import com.b07.exceptions.UserIdNotInDatabaseException;
import com.b07.inventory.Item;
import com.b07.store.Sale;
import com.b07.models.User;
import java.math.BigDecimal;
import com.b07.exceptions.EmptyStringException;
import com.b07.exceptions.InvalidAddressException;
import com.b07.exceptions.InvalidAgeException;
import com.b07.exceptions.RoleNotInDatabaseException;

import java.util.List;

/**
 * Created by kevinshen on 2017-11-29.
 */

public class DatabaseInsertHelperAndroid {

  private Context activityContext;

  public DatabaseInsertHelperAndroid(Context activityContext) {
    this.activityContext = activityContext;
  }

  /**
   * Inserts a role into android db.
   *
   * @param role a new role
   * @return id of new inserted role
   */
  public int insertRole(String role) throws EmptyStringException {
    DatabaseDriverAndroid insertDatabase = new DatabaseDriverAndroid(activityContext);
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(activityContext);
    int result = -1;
    if (role.equals(null) || role.equals("")) {
      insertDatabase.close();
      throw new EmptyStringException();
    } else {
      result = (int) insertDatabase.insertRole(role);
    }
    // close database after use
    insertDatabase.close();
    // return result
    return result;
  }

  /**
   * Inserts a new user.
   *
   * @param name of user
   * @param age of user
   * @param address of user
   * @param password of user
   * @return id of new inserted user
   */
  public int insertNewUser(String name, int age, String address, String password)
      throws InvalidAgeException, InvalidAddressException {
    DatabaseDriverAndroid insertDatabase = new DatabaseDriverAndroid(activityContext);
    int result = -1;
    if (age <= 0) {
      insertDatabase.close();
      throw new InvalidAgeException();
    } else if (address.equals(null) || address.equals("") || address.length() > 100) {
      insertDatabase.close();
      throw new InvalidAddressException();
    } else {
      result = (int) insertDatabase.insertNewUser(name, age, address, password);
    }
    // close database after use
    insertDatabase.close();
    // return result
    return result;
  }

  /**
   * Insert new account into android db.
   *
   * @param userId owner of account
   * @param active true if account active other wise false
   * @return id of new inserted account
   */
  public int insertAccount(int userId, boolean active) throws UserIdNotInDatabaseException {
    // make new object
    DatabaseDriverAndroid insertDatabase = new DatabaseDriverAndroid(activityContext);
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(activityContext);
    // insert and cast the id result as int
    try {
      boolean contain = selectHelper.getUsersDetails()
          .contains(selectHelper.getUserDetails(userId));
    } catch (UserIdNotInDatabaseException e) {
      insertDatabase.close();
      throw new UserIdNotInDatabaseException();
    }
    int result = (int) insertDatabase.insertAccount(userId, active);
    // close database after use
    insertDatabase.close();
    // return result
    return result;
  }

  /**
   * Insert new item into android db.
   *
   * @param name of item
   * @param price of item in big decimal
   * @return id of new inserted item
   */
  public int insertItem(String name, BigDecimal price)
      throws EmptyStringException, InvalidPriceException, ItemIdNotInDatabaseException,
      ItemNameAlreadyInDatabaseException {
    // make new object
    DatabaseDriverAndroid insertDatabase = new DatabaseDriverAndroid(activityContext);
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(activityContext);
    List<Item> itemsInDatabase = selectHelper.getAllItems();
    boolean itemInDatabase = false;
    for (Item item : itemsInDatabase) {
      if (item.getName().equals(name)) {
        itemInDatabase = true;
      }
    }
    int result = -1;
    if (name.equals(null) || name.equals("")) {
      insertDatabase.close();
      throw new EmptyStringException();
    } else if (price.equals(null)) {
      insertDatabase.close();
      throw new InvalidPriceException();
    } else if (itemInDatabase) {
      insertDatabase.close();
      throw new ItemNameAlreadyInDatabaseException();
    } else {
      // insert and cast the id result as int
      result = (int) insertDatabase.insertItem(name, price);
    }
    // close database after use
    insertDatabase.close();
    // return result
    return result;
  }

  /**
   * Insert new sale into android db.
   *
   * @param userId id of user's sale
   * @param totalPrice total price of sales log
   * @return id of new inserted of sale
   */
  public int insertSale(int userId, BigDecimal totalPrice) throws UserIdNotInDatabaseException {
    // make new object
    DatabaseDriverAndroid insertDatabase = new DatabaseDriverAndroid(activityContext);
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(activityContext);
    int result = -1;
    try {
      User user = selectHelper.getUserDetails(userId);
      result = (int) insertDatabase.insertSale(userId, totalPrice);
    } catch (UserIdNotInDatabaseException e) {
      insertDatabase.close();
      throw new UserIdNotInDatabaseException();
    }
    // insert and cast the id result as int

    // close database after use
    insertDatabase.close();
    // return result
    return result;
  }

  /**
   * Insert new inventory into android db.
   *
   * @param itemId id of item
   * @param quantity number of items
   * @return id of new inserted inventory
   */
  public int insertInventory(int itemId, int quantity)
      throws InvalidQuantityException, ItemIdNotInDatabaseException {
    // make new object
    DatabaseDriverAndroid insertDatabase = new DatabaseDriverAndroid(activityContext);
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(activityContext);

    if (quantity < 0) {
      insertDatabase.close();
      throw new InvalidQuantityException();
    }

    try {
      selectHelper.getItem(itemId);
    } catch (ItemIdNotInDatabaseException e) {
      insertDatabase.close();
      throw new ItemIdNotInDatabaseException();
    }
    // insert and cast the id result as int
    int result = (int) insertDatabase.insertInventory(itemId, quantity);
    // close database after use
    insertDatabase.close();
    // return result
    return result;
  }

  /**
   * Insert new account line into android db.
   *
   * @param accountId id of new account
   * @param itemId id of item
   * @param quantity number
   * @return id of new inserted account line
   */
  public int insertAccountLine(int accountId, int itemId, int quantity)
      throws ItemNotInDatabaseException, AccountNotInDatabaseException, InvalidQuantityException {
    // make new object
    DatabaseDriverAndroid insertDatabase = new DatabaseDriverAndroid(activityContext);
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(activityContext);
    if (quantity < 0) {
      insertDatabase.close();
      throw new InvalidQuantityException();
    }
    try {
      selectHelper.getItem(itemId);
      selectHelper.getAccountDetails(accountId);
    } catch (ItemIdNotInDatabaseException e) {
      insertDatabase.close();
      throw new ItemNotInDatabaseException();
    } catch (AccountNotInDatabaseException e) {
      insertDatabase.close();
      throw new AccountNotInDatabaseException();
    }

    // insert and cast the id result as int
    int result = (int) insertDatabase.insertAccountLine(accountId, itemId, quantity);
    // close database after use
    insertDatabase.close();
    // return result
    return result;
  }

  /**
   * Insert itemized sale into android db.
   *
   * @param saleId id of sale
   * @param itemId id of item
   * @param quantity nunmber of items in sale
   * @return id of new inserted itemized sale
   */
  public int insertItemizedSale(int saleId, int itemId, int quantity)
      throws SalesIdNotInDatabaseException, ItemIdNotInDatabaseException, InvalidQuantityException {
    // make new object
    DatabaseDriverAndroid insertDatabase = new DatabaseDriverAndroid(activityContext);
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(activityContext);
    int result = -1;
    // insert and cast the id result as int
    try {
      Sale sale = selectHelper.getSaleById(saleId);
      Item item = selectHelper.getItem(itemId);
      if (quantity < 0) {
        throw new InvalidQuantityException();
      }
      result = (int) insertDatabase.insertItemizedSale(saleId, itemId, quantity);
    } catch (SalesIdNotInDatabaseException e) {
      throw new SalesIdNotInDatabaseException();
    } catch (ItemIdNotInDatabaseException e) {
      throw new ItemIdNotInDatabaseException();
    } finally {
      // close database after use
      insertDatabase.close();
      // return result
      return result;
    }

  }

  /**
   * insert new role for user in android db.
   *
   * @param userId id of user
   * @param roleId id of role
   * @return id of new inserted role for user
   */
  public int insertUserRole(int userId, int roleId)
      throws UserIdNotInDatabaseException, RoleNotInDatabaseException {
    // make new object
    DatabaseDriverAndroid insertDatabase = new DatabaseDriverAndroid(activityContext);
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(activityContext);
    try {
      selectHelper.getRole(roleId);
    } catch (RoleIdNotInDatabaseException e) {
      insertDatabase.close();
      throw new RoleNotInDatabaseException();
    }
    // insert and cast the id result as int
    int result = (int) insertDatabase.insertUserRole(userId, roleId);
    // close database after use
    insertDatabase.close();
    // return result
    return result;
  }
}
