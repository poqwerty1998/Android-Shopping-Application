package com.b07.account;

public enum AccountTypes {
  ADMIN, CUSTOMER;

  public static boolean containEnum(String account) {
    boolean contain = false;
    if (account.equalsIgnoreCase(ADMIN.toString())) {
      contain = true;
    } else if (account.equalsIgnoreCase(CUSTOMER.toString())) {
      contain = true;
    }
    return contain;
  }
}
