package com.b07.setup;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import com.b07.database.DatabaseInsertHelperAndroid;
import com.b07.controllers.AdminInserterController;
import com.b07.taoboe.R;
import java.math.BigDecimal;


public class SetupActivity extends AppCompatActivity {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.initialize_start_page);
    DatabaseInsertHelperAndroid insertHelperAndroid = new DatabaseInsertHelperAndroid(
        getApplicationContext());
    Button startButton = findViewById(R.id.startButton);
    startButton.setOnClickListener(buttonListener);
    try {
      int firstItemId = insertHelperAndroid.insertItem("Beezys Boost 360",
          new BigDecimal("40"));
      int secondItemId = insertHelperAndroid.insertItem("Fishing Rod",
          new BigDecimal("10"));
      int thirdItemId = insertHelperAndroid.insertItem("Original Hockey Stick",
          new BigDecimal("90"));
      int fourthItemId = insertHelperAndroid.insertItem("Skates",
          new BigDecimal("50"));
      int fifthItemId = insertHelperAndroid.insertItem("Protein Bar",
          new BigDecimal("2"));
      insertHelperAndroid.insertInventory(firstItemId, 10);
      insertHelperAndroid.insertInventory(secondItemId, 60);
      insertHelperAndroid.insertInventory(thirdItemId, 30);
      insertHelperAndroid.insertInventory(fourthItemId, 39);
      insertHelperAndroid.insertInventory(fifthItemId, 1000);
    } catch (Exception e) {
      Toast.makeText(getApplicationContext(), "Setup Does Not Work",
          Toast.LENGTH_SHORT).show();
    }
  }

  private View.OnClickListener buttonListener = new View.OnClickListener() {
    public void onClick(View v) {
      switch (v.getId()) {
        case R.id.startButton:
          Intent nextIntent = new Intent(SetupActivity.this,
              AdminInserterController.class);
          nextIntent.putExtra("isFirstRun", true);
          startActivity(nextIntent);
      }
    }
  };

  @Override
  public void onBackPressed() {
  }
}
