package com.b07.models;

import android.content.Context;
import com.b07.database.DatabaseSelectHelperAndroid;
import java.io.Serializable;
import java.sql.SQLException;
import com.b07.exceptions.UserIdNotInDatabaseException;
import com.b07.security.PasswordHelpers;

public abstract class User {

  private int id;
  private String name;
  private int age;
  private String address;
  private int roleId;
  private boolean authenticated;
  private Context context;

  /**
   * This will initialize the User
   *
   * @param id the userId of user.
   * @param name the name of the user.
   * @param age the age of the user in integer.
   * @param address the address of the user that is less than or equal to 100 chars.
   * @param roleId the role of the user.
   */
  public User(int id, String name, int age, String address, int roleId, Context context) {
    this.id = id;
    this.name = name;
    this.age = age;
    this.address = address;
    this.roleId = roleId;
    this.authenticated = false;
    this.context = context;
  }

  /**
   * This will initialize the User
   *
   * @param id the userId of user.
   * @param name the name of the user.
   * @param age the age of the user in integer.
   * @param address the address of the user that is less than or equal to 100 chars.
   * @param roleId the role of the user.
   * @param authenticated if the user is authenticated or not.
   */
  public User(int id, String name, int age, String address, int roleId,
      boolean authenticated, Context context) {
    this.id = id;
    this.name = name;
    this.age = age;
    this.address = address;
    this.roleId = roleId;
    this.authenticated = authenticated;
  }

  /**
   * This will get the id of the User
   *
   * @return id of the user
   */
  public int getId() {
    return this.id;
  }

  /**
   * This will set the id of the User
   *
   * @param id the id of the user
   */
  public void setId(int id) {
    this.id = id;
  }

  /**
   * This will get the name of the User
   *
   * @return the name of the user
   */
  public String getName() {
    return this.name;
  }

  /**
   * This will set the name of the User
   *
   * @param name the name of the user
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * This will get the age of the User
   *
   * @return the age of the user
   */
  public int getAge() {
    return this.age;
  }

  /**
   * This will set the age of the User
   *
   * @param age the age of the user in years
   */
  public void setAge(int age) {
    this.age = age;
  }

  /**
   * This will get the role of the User
   *
   * @return the roleId of the role of the user
   */
  public int getRoleId() {
    return this.roleId;
  }

  /**
   * This will get the role of the User
   *
   * @return the roleId of the role of the user
   */
  public void setRoleId(int roleId) {
    this.roleId = roleId;
  }

  /**
   * This will get the address of the User
   *
   * @return the address of the user
   */
  public String getAddress() {
    return this.address;
  }

  /**
   * This will set the address of the User
   *
   * @param address the address of the user with 100 or less characters
   */
  public void setAddress(String address) {
    this.address = address;
  }

  /**
   * This will authenticate the user given a password
   *
   * @param password the associated password of the user
   * @return if the user was authenticated or not given the password
   */
  public final boolean authenticate(String password)
      throws SQLException, UserIdNotInDatabaseException {
    boolean result = false;
    String dbPassword;
    try {
      DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(this.context);
      dbPassword = selectHelper.getPassword(this.getId());
      result = PasswordHelpers.comparePassword(dbPassword, password);
    } catch (UserIdNotInDatabaseException e) {
      throw new UserIdNotInDatabaseException();
    }
    this.authenticated = result;
    return result;
  }

  /**
   * This will give if the user is authenticated or not
   *
   * @return user authenticated or not
   */
  public boolean isAuthenticated() {
    return this.authenticated;
  }
}
