package com.b07.inventory;

public enum ItemTypes {
  FISHING_ROD, HOCKEY_STICK, SKATES, RUNNING_SHOES, PROTEIN_BAR;


  public static boolean containEnum(String type) {
    boolean contain = false;
    if (type.equalsIgnoreCase(FISHING_ROD.toString())) {
      contain = true;
    } else if (type.equalsIgnoreCase(HOCKEY_STICK.toString())) {
      contain = true;
    } else if (type.equalsIgnoreCase(SKATES.toString())) {
      contain = true;
    } else if (type.equalsIgnoreCase(RUNNING_SHOES.toString())) {
      contain = true;
    } else if (type.equalsIgnoreCase(PROTEIN_BAR.toString())) {
      contain = true;
    }
    return contain;
  }
}
