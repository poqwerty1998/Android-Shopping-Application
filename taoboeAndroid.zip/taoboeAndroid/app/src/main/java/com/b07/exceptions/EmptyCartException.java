package com.b07.exceptions;

public class EmptyCartException extends Exception {

  private static final long serialVersionUID = 6195755701775153665L;

  public EmptyCartException() {
  }

  public EmptyCartException(String message) {
    super(message);
  }

  public EmptyCartException(Throwable cause) {
    super(cause);
  }

  public EmptyCartException(String message, Throwable cause) {
    super(message, cause);
  }

  public EmptyCartException(String message, Throwable cause, boolean enableSuppression,
      boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }

}
