package com.b07.store;

import java.math.BigDecimal;
import java.util.List;

public interface SalesLog {

  /**
   * This adds a sale to the log.
   *
   * @param sale is the Sale that is to be added to the log.
   */
  public void addSale(Sale sale);

  /**
   * This returns a list of all the sales made.
   *
   * @return a list of all the sales.
   */
  public List<Sale> getSales();

  /**
   * This gets the total number of sales.
   *
   * @return int indicating how many sales were made.
   */
  public int getTotalSales();

  /**
   * This sets the number of sales to numSales.
   *
   * @param numSales is the number of sales being set to.
   */
  public void setTotalSales(int totalSales);

  /**
   * This gets the total amount of money made from sales.
   *
   * @return BigDecimal representation of the money made from sales.
   */
  public BigDecimal getTotalPrice();

  /**
   * This sets the total amount of money made from sales.
   *
   * @param total is the total price being set to.
   */
  public void setTotalPrice(BigDecimal totalPrice);
}
