package com.b07.views;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import com.b07.adapters.AccountAdapter;
import com.b07.database.DatabaseSelectHelperAndroid;
import com.b07.taoboe.R;
import java.util.ArrayList;

/**
 * Created by Qi on 12/3/2017.
 */

public class AccountsListView extends AppCompatActivity {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.listview_account);
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(getApplicationContext());
    final ArrayList<Integer> account = getIntent().getExtras().getIntegerArrayList("account");
    ArrayAdapter<Integer> adapter = new AccountAdapter(getApplicationContext(), account);
    ListView testListView = (ListView) findViewById(R.id.accountList);
    testListView.setAdapter(adapter);

    testListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
      @Override
      public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        int accountId = (Integer)parent.getItemAtPosition(position);
        Intent nextIntent = new Intent();
        nextIntent.putExtra("currentAccountId", accountId);
        setResult(Activity.RESULT_OK, nextIntent);

        finish();

      }
    });

  }
}
