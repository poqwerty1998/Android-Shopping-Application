package com.b07.views;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import com.b07.adapters.ShoppingCartAdapter;
import com.b07.database.DatabaseSelectHelperAndroid;
import com.b07.taoboe.R;
import java.util.ArrayList;


/**
 * Created by Qi on 12/2/2017.
 */

public class ShoppingCartListView extends AppCompatActivity {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.listview_shopping_cart);
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(
        getApplicationContext());
    ArrayList<String> itemName = getIntent().getExtras().getStringArrayList("itemNames");
    ArrayList<Integer> quantity = getIntent().getExtras().getIntegerArrayList("quantity");

    ArrayAdapter<String> adapter = new ShoppingCartAdapter(getApplicationContext(), itemName,
        quantity);
    ListView testListView = (ListView) findViewById(R.id.shopping_cart);
    testListView.setAdapter(adapter);

  }
}
