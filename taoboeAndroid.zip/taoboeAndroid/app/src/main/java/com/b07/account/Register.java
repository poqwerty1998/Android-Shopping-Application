package com.b07.account;

import java.sql.SQLException;
import com.b07.exceptions.RoleIdNotInDatabaseException;
import com.b07.exceptions.UserIdNotInDatabaseException;
import com.b07.models.Customer;

public interface Register {

  /**
   * register the customer.
   *
   * @param userId the given customer's user id
   * @return the Customer object
   * @throws UserIdNotInDatabaseException if the given user id is not in database
   * @throws RoleIdNotInDatabaseException if role Customer does not exist in database
   * @throws SQLException if sql runs into any errors
   */
  public Customer registerCustomerAccount(int userId)
      throws SQLException, RoleIdNotInDatabaseException, UserIdNotInDatabaseException;
}
