package com.b07.exceptions;

/**
 * Created by kevinshen on 2017-11-30.
 */

public class ItemNameAlreadyInDatabaseException extends Exception {
    private static final long serialVersionUID = 2783220556189544427L;
}
