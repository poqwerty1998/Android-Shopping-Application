package com.b07.account;

import android.content.Context;
import com.b07.database.DatabaseSelectHelperAndroid;
import com.b07.exceptions.AccountNotInDatabaseException;
import com.b07.exceptions.DatabaseInsertException;
import com.b07.exceptions.InsufficientStockException;
import com.b07.exceptions.InvalidQuantityException;
import com.b07.exceptions.ItemIdNotInDatabaseException;
import com.b07.exceptions.RoleIdNotInDatabaseException;
import com.b07.exceptions.UserIdNotInDatabaseException;
import com.b07.store.ShoppingCart;
import com.b07.models.Customer;
import com.b07.models.User;
import java.sql.SQLException;
import java.util.HashMap;


public class CustomerAccount extends Account {

  private boolean registered;
  private ShoppingCart shoppingCart;
  private Context context;

  public CustomerAccount(int id, int userId, Context context) {
    super(id, userId);
    this.registered = false;
    this.context = context;
  }

  public CustomerAccount(int id, int userId, boolean registered, Context context) {
    super(id, userId);
    this.registered = registered;
    this.context = context;
  }

  public CustomerAccount(int id, int userId, boolean registered, ShoppingCart shoppingCart,
      Context context) {
    super(id, userId);
    this.registered = registered;
    this.shoppingCart = shoppingCart;
    this.context = context;
  }

  /**
   * Gets all the data needed and creates a shopping cart object.
   *
   * @return a shopping cart object with all needed data
   * @throws SQLException thrown when sql runs into issues
   * @throws RoleIdNotInDatabaseException thrown when user has invalid role in db
   * @throws UserIdNotInDatabaseException thrown when user is not in db
   * @throws DatabaseInsertException thrown when database cant insert values
   * @throws ItemIdNotInDatabaseException thrown when itemid that user has does not exist
   */
  public ShoppingCart getPreviousShoppingCart()
      throws SQLException, RoleIdNotInDatabaseException, AccountNotInDatabaseException,
      UserIdNotInDatabaseException, DatabaseInsertException, ItemIdNotInDatabaseException, InsufficientStockException, InvalidQuantityException {
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(context);
    // get person from id
    User user = selectHelper.getUserDetails(this.userId);
    // make shopping cart for person
    ShoppingCart cart = new ShoppingCart((Customer) user, context);
    // get sales by user id for customer
    HashMap<Integer, Integer> sales = selectHelper.getAccountDetails(user.getId());
    // loop through the hashmap and add each one into the shopping cart
    for (HashMap.Entry<Integer, Integer> entry : sales.entrySet()) {
      // add the item and quantity from each sales listed into shoppinig cart
      cart.addItem(selectHelper.getItem(entry.getKey()), entry.getValue());
    }
    // return shopping cart
    return cart;
  }

  public ShoppingCart getShoppingCart() {
    return this.shoppingCart;
  }

  public void setShoppingCart(ShoppingCart shoppingCart) {
    this.shoppingCart = shoppingCart;
  }

  public boolean isRegistered() {
    return this.registered;
  }
}
