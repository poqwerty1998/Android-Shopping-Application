package com.b07.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;
import com.b07.database.DatabaseSelectHelperAndroid;
import com.b07.taoboe.R;
import java.util.ArrayList;

/**
 * Created by Qi on 12/2/2017.
 */

public class ShoppingCartAdapter extends ArrayAdapter<String> {
  private ArrayList<String> itemNames;
  private ArrayList<Integer> quantityList;

  public ShoppingCartAdapter(Context context, ArrayList<String> data, ArrayList<Integer> quantityList) {
    super(context, R.layout.custom_card_shopping_cart, data);
    this.quantityList = quantityList;
    if(data.isEmpty()){ Toast.makeText(getContext(),"Empty Shopping Cart", Toast.LENGTH_SHORT).show();}
  }

  @Override
  public View getView(int position, View convertView, ViewGroup parent) {
    DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(this.getContext());
    LayoutInflater myCustomInflater = LayoutInflater.from(this.getContext());
    View customView = myCustomInflater.inflate(R.layout.custom_card_shopping_cart, parent, false);
    // get references.

    TextView itemName = (TextView) customView.findViewById(R.id.itemName);
    TextView quantity = (TextView) customView.findViewById(R.id.quantity);
    try {
      int quantityId = this.quantityList.get(position);
      String name = getItem(position);
      quantity.setText("Quantity : " + quantityId);
      itemName.setText(name);
    } catch (Exception e) {
      Toast.makeText(getContext(), "some exception", Toast.LENGTH_SHORT).show();
    }

    return customView;
  }
}
