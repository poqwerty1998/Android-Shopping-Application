package com.b07.exceptions;

public class RoleNameAlreadyInDatabaseException extends Exception {

  private static final long serialVersionUID = -6586922548609693166L;

  public RoleNameAlreadyInDatabaseException() {
  }

  public RoleNameAlreadyInDatabaseException(String message) {
    super(message);
  }

  public RoleNameAlreadyInDatabaseException(Throwable cause) {
    super(cause);
  }

  public RoleNameAlreadyInDatabaseException(String message, Throwable cause) {
    super(message, cause);
  }

  public RoleNameAlreadyInDatabaseException(String message, Throwable cause,
      boolean enableSuppression, boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }

}
