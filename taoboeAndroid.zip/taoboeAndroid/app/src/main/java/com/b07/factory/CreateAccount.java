package com.b07.factory;

import android.content.Context;

public interface CreateAccount {

  /**
   * create account for a customer.
   *
   * @param userId the id of the customer.
   * @return true if the account was created for that customer.
   */
  public boolean createCustomerAccount(int userId, Context context);
}
