
package com.b07.serialize;

import android.content.Context;
import com.b07.database.DatabaseDriverAndroid;
import com.b07.database.DatabaseInsertHelperAndroid;
import com.b07.exceptions.AccountNotInDatabaseException;
import com.b07.exceptions.ItemNameAlreadyInDatabaseException;
import com.b07.exceptions.ItemNotInDatabaseException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import com.b07.exceptions.DatabaseInsertException;
import com.b07.exceptions.EmptyStringException;
import com.b07.exceptions.InvalidAddressException;
import com.b07.exceptions.InvalidAgeException;
import com.b07.exceptions.InvalidPriceException;
import com.b07.exceptions.InvalidQuantityException;
import com.b07.exceptions.ItemIdNotInDatabaseException;
import com.b07.exceptions.RoleIdNotInDatabaseException;
import com.b07.exceptions.RoleNameAlreadyInDatabaseException;
import com.b07.exceptions.RoleNotInDatabaseException;
import com.b07.exceptions.SalesIdNotInDatabaseException;
import com.b07.exceptions.UserIdNotInDatabaseException;
import com.b07.exceptions.UserNotInDatabaseException;
import com.b07.inventory.Item;
import com.b07.store.Sale;
import com.b07.models.User;

public class Deserialize {

  private transient Context context;

  public Deserialize(Context context) {
    this.context = context;
  }

  //ok

  /**
   * Insert the all serialized users into the database.
   *
   * @param serializeDatabase is the serialized database
   * @throws DatabaseInsertException if something goes wrong with the database
   * @throws SQLException if something goes wrong with sql
   * @throws EmptyStringException if the name is an empty string
   * @throws InvalidAgeException if the age is not valid
   * @throws InvalidAddressException if the address is not valid
   */
  private void insertUsers(SerializeDatabase serializeDatabase)
      throws DatabaseInsertException, SQLException, EmptyStringException, InvalidAgeException,
      InvalidAddressException {
    DatabaseInsertHelperAndroid insertHelper = new DatabaseInsertHelperAndroid(this.context);
    // get all users from the database
    List<User> users = serializeDatabase.getUsers();
    // user passwords
    HashMap<Integer, String> userPasswords = serializeDatabase.getUserPassword();
    // iterate over the map
    for (User user : users) {
      String name = user.getName();
      int age = user.getAge();
      String address = user.getAddress();
      String password = userPasswords.get(user.getId());
      // insert the user in to the database
      insertHelper.insertNewUser(name, age, address, password);
    }
  }

  //ok

  /**
   * Insert all serialized user roles into the database.
   *
   * @param serializeDatabase is the serialized database
   * @throws SQLException if something goes wrong with sql
   * @throws Exception if userId or roleId not in database, or if user's role in database does not
   * match the input roleId
   */
  private void insertUserRole(SerializeDatabase serializeDatabase)
      throws UserIdNotInDatabaseException, RoleNotInDatabaseException {
    DatabaseInsertHelperAndroid insertHelper = new DatabaseInsertHelperAndroid(this.context);
    // get all user roles from the database
    HashMap<Integer, List<Integer>> userRoles = serializeDatabase.getUserRole();
    // iterate over the map
    for (Integer roleId : userRoles.keySet()) {
      List<Integer> usersWithRoleId = userRoles.get(roleId);
      // loop through the users with this userId
      for (int userId : usersWithRoleId) {
        // insert the user and its role id in to the database
        insertHelper.insertUserRole(userId, roleId);
      }
    }
  }

  //ok

  /**
   * Insert all serialized roles into the database.
   *
   * @param serializeDatabase is the serialized database
   * @throws NullPointerException if the name is null
   * @throws DatabaseInsertException if something goes wrong when inserting into the database
   * @throws SQLException if something goes wrong with sql
   * @throws RoleNameAlreadyInDatabaseException if the role name is already in the database
   * @throws EmptyStringException if name is an empty string
   * @throws RoleNotInDatabaseException if the id of the role is not in the database
   */
  private void insertRoles(SerializeDatabase serializeDatabase)
      throws NullPointerException, DatabaseInsertException, SQLException,
      RoleNameAlreadyInDatabaseException, EmptyStringException, RoleNotInDatabaseException {
    DatabaseInsertHelperAndroid insertHelper = new DatabaseInsertHelperAndroid(this.context);
    // get all roles from the database
    HashMap<Integer, String> roles = serializeDatabase.getRoles();
    // iterate over the map
    for (Integer roleId : roles.keySet()) {
      // add the role to the database
      insertHelper.insertRole(roles.get(roleId));
    }
  }

  /**
   * Insert all serialized sales into the database.
   *
   * @param serializeDatabase is the serialized database
   * @throws DatabaseInsertException if something goes wrong when inserting into the database
   * @throws SQLException if something goes wrong with sql
   * @throws UserNotInDatabaseException if the user is not in the database
   * @throws RoleIdNotInDatabaseException if the role id does not exist in the database
   * @throws UserIdNotInDatabaseException if the user id does not exist in the database
   */
  private void insertSales(SerializeDatabase serializeDatabase)
      throws DatabaseInsertException, SQLException, UserNotInDatabaseException,
      RoleIdNotInDatabaseException, UserIdNotInDatabaseException {
    DatabaseInsertHelperAndroid insertHelper = new DatabaseInsertHelperAndroid(this.context);
    // get all roles from the database
    List<Sale> sales = serializeDatabase.getSales();
    // iterate over the map
    for (Sale sale : sales) {
      int userId = sale.getId();
      BigDecimal totalPrice = sale.getTotalPrice();
      // insert the sale into the database
      insertHelper.insertSale(userId, totalPrice);
    }
  }

  /**
   * Insert all serialized itemized sales into the database.
   *
   * @param serializeDatabase is the serialized database
   * @throws DatabaseInsertException if something goes wrong when inserting into the database
   * @throws SQLException if something goes wrong with sql
   * @throws SalesIdNotInDatabaseException if the sale id does not exist in the database
   * @throws ItemIdNotInDatabaseException if the item id does not exist in the database
   * @throws InvalidQuantityException if the quantity of the item is not a valid quantity
   * @throws RoleIdNotInDatabaseException if the role id does not exist in the database
   * @throws UserIdNotInDatabaseException if the user id does not exist in the database
   */
  private void insertItemizedSales(SerializeDatabase serializeDatabase)
      throws DatabaseInsertException, SQLException, SalesIdNotInDatabaseException,
      ItemIdNotInDatabaseException, InvalidQuantityException, RoleIdNotInDatabaseException,
      UserIdNotInDatabaseException {
    DatabaseInsertHelperAndroid insertHelper = new DatabaseInsertHelperAndroid(this.context);
    // get all itemized sales from the database
    HashMap<Integer, HashMap<Item, Integer>> itemizedSales = serializeDatabase.getItemizedSales();
    // iterate over the map
    for (Integer saleId : itemizedSales.keySet()) {
      // iterate over the item map
      for (Item item : itemizedSales.get(saleId).keySet()) {
        int itemId = item.getId();
        int quantity = itemizedSales.get(saleId).get(item).intValue();
        // insert the itemized sale into the database
        insertHelper.insertItemizedSale(saleId, itemId, quantity);
      }
    }
  }

  //ok

  /**
   * Insert all items into the database.
   *
   * @param serializeDatabase is the serialized database
   * @throws NullPointerException if the name of the item is a null
   * @throws DatabaseInsertException if something goes wrong when inserting into the database
   * @throws SQLException if something goes wrong sql
   * @throws EmptyStringException if the name of the item is an empty string
   * @throws InvalidPriceException if the price of the item is not valid
   */
  private void insertItems(SerializeDatabase serializeDatabase) throws InvalidPriceException,
      EmptyStringException, ItemIdNotInDatabaseException, ItemNameAlreadyInDatabaseException {
    DatabaseInsertHelperAndroid insertHelper = new DatabaseInsertHelperAndroid(this.context);
    // get all items from the database
    List<Item> items = serializeDatabase.getItems();
    // iterate over the map
    for (Item item : items) {
      String name = item.getName();
      BigDecimal price = item.getPrice();
      // insert the item into the database
      insertHelper.insertItem(name, price);
    }
  }

  //ok

  /**
   * Insert all items into the inventory in the database.
   *
   * @param serializeDatabase is the serialized database
   * @throws DatabaseInsertException when something goes wrong when inserting into the database
   * @throws SQLException if something goes wrong with sql
   * @throws ItemIdNotInDatabaseException if the id of the item is not in the database
   * @throws InvalidQuantityException if the quantity of the item is not valid
   */
  private void insertInventory(SerializeDatabase serializeDatabase)
      throws DatabaseInsertException, SQLException, ItemIdNotInDatabaseException,
      InvalidQuantityException {
    DatabaseInsertHelperAndroid insertHelper = new DatabaseInsertHelperAndroid(this.context);
    // get the inventory from the database
    HashMap<Item, Integer> inventory = serializeDatabase.getInventory();
    // iterate over the map
    for (Item item : inventory.keySet()) {
      int itemId = item.getId();
      int quantity = inventory.get(item).intValue();
      // add the item to the inventory int the database
      insertHelper.insertInventory(itemId, quantity);
    }
  }

  //ok

  /**
   * Insert all serialized account summaries into the database
   *
   * @param serializeDatabase is the serialized database
   * @throws DatabaseInsertException if something goes wrong when inserting into the database
   * @throws SQLException if something goes wrong with sql
   */
  private void insertAccountSummary(SerializeDatabase serializeDatabase)
      throws ItemNotInDatabaseException, AccountNotInDatabaseException, InvalidQuantityException {
    DatabaseInsertHelperAndroid insertHelper = new DatabaseInsertHelperAndroid(this.context);
    // get the account summaries from the database
    HashMap<Integer, HashMap<Integer, Integer>> accountSummary =
        serializeDatabase.getAccountSummary();
    // iterate over the map
    for (Integer accountId : accountSummary.keySet()) {
      // iterate over the item ids
      for (Integer itemId : accountSummary.get(accountId).keySet()) {
        int quantity = accountSummary.get(accountId).get(itemId);
        // add the account summary into the database
        insertHelper.insertAccountLine(accountId, itemId, quantity);
      }
    }
  }

  //ok

  /**
   * Insert all accounts into the database.
   *
   * @param serializeDatabase is the serialized database
   * @throws DatabaseInsertException when something goes wrong when inserting into the database
   * @throws SQLException if something goes wrong with sql
   */
  private void insertAccount(SerializeDatabase serializeDatabase)
      throws DatabaseInsertException, UserIdNotInDatabaseException {
    DatabaseInsertHelperAndroid insertHelper = new DatabaseInsertHelperAndroid(this.context);
    // get all accounts from the database
    HashMap<Integer, HashMap<Integer, Boolean>> accounts = serializeDatabase.getAccount();
    for (Integer userId : accounts.keySet()) {
      // go through all accounts associated with this user
      for (Integer accountId : accounts.get(userId).keySet()) {
        boolean status = accounts.get(userId).get(accountId);
        // insert the account into the database
        insertHelper.insertAccount(userId, status);
      }
    }
  }

  /**
   * Deserializes the serialized file.
   */
  public void deserialize()
      throws IOException, ClassNotFoundException, NullPointerException, DatabaseInsertException {
    try {
      // read the serialized file
      FileInputStream fileIn = new FileInputStream("./app/src/main/java/com/b07/database_copy.ser");
      ObjectInputStream in = new ObjectInputStream(fileIn);
      SerializeDatabase serializeDatabase = (SerializeDatabase) in.readObject();
      DatabaseDriverAndroid database = new DatabaseDriverAndroid(this.context);
      database.onUpgrade(database.getWritableDatabase(), 1, 2);
      // insert all the information into the database
      insertUsers(serializeDatabase);
      insertUserRole(serializeDatabase);
      insertRoles(serializeDatabase);
      insertSales(serializeDatabase);
      insertItemizedSales(serializeDatabase);
      insertItems(serializeDatabase);
      insertInventory(serializeDatabase);
      insertAccountSummary(serializeDatabase);
      //insertAccount(serializeDatabase);
      // close the file
      in.close();
      fileIn.close();
    } catch (IOException e) {
      System.out.println("Something went wrong when reading the file.");
    } catch (ClassNotFoundException e) {
      System.out.println("Database not found.");
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
