package com.b07.market;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.b07.database.DatabaseSelectHelperAndroid;
import com.b07.taoboe.R;
import com.b07.models.Admin;
import com.b07.models.Roles;

public class AdminLoginActivity extends AppCompatActivity {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_user_login);
    TextView loginTitle = findViewById(R.id.login_title);
    loginTitle.setText("ADMIN LOGIN");

    Button adminSignInButton = findViewById(R.id.signInButton);
    ImageButton backButton = findViewById(R.id.backButton);

    adminSignInButton.setOnClickListener(buttonListener);
    backButton.setOnClickListener(buttonListener);

    RelativeLayout mLayout = (RelativeLayout) findViewById(R.id.userLoginLayout);
    mLayout.setBackgroundResource(R.drawable.admin_login_background);

  }

  private View.OnClickListener buttonListener = new View.OnClickListener() {
    public void onClick(View v) {
    Intent nextIntent;
    EditText adminUserInput = findViewById(R.id.userInput);
    EditText adminPasswordInput = findViewById(R.id.passwordInput);

    switch (v.getId()) {
      case R.id.signInButton:
        Context context = getApplicationContext();
        if (adminUserInput.getText().toString().isEmpty()
            || adminPasswordInput.getText().toString().isEmpty()) {
          Toast.makeText(context, "Empty Fields", Toast.LENGTH_SHORT).show();
        } else {
          int userInput = Integer.valueOf(adminUserInput.getText().toString());
          String passwordInput = adminPasswordInput.getText().toString();

          verify(context, userInput, passwordInput);
        }
        return;

      case R.id.backButton:
        nextIntent = new Intent(AdminLoginActivity.this, MainActivity.class);
        startActivity(nextIntent);
        return;

    }

    }
  };

  private void verify(Context context, int userInput, String passwordInput) {
    Intent nextIntent;
    try {
      DatabaseSelectHelperAndroid selectHelper = new DatabaseSelectHelperAndroid(context);
      Admin admin = (Admin) selectHelper.getUserDetails(userInput);
      boolean result = admin.authenticate(passwordInput);
      String role = selectHelper.getRole(selectHelper.getUserRole(userInput));
      if (result && role.equalsIgnoreCase(Roles.ADMIN.toString())) {
        nextIntent = new Intent(AdminLoginActivity.this, AdminInterfaceActivity.class);
        nextIntent.putExtra("adminId", admin.getId());
        startActivity(nextIntent);
      } else if (!result) {
        Toast.makeText(context, "Invalid password", Toast.LENGTH_SHORT).show();
      } else if (!role.equalsIgnoreCase(Roles.ADMIN.toString())) {
        Toast.makeText(context, "Not customer account", Toast.LENGTH_SHORT).show();
      }
    } catch (Exception e) {
      Toast.makeText(context, "Invalid user name or password", Toast.LENGTH_SHORT).show();
    }
  }

  ;
}
