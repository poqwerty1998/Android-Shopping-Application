package com.b07.views;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import com.b07.taoboe.R;
import java.util.ArrayList;

/**
 * Created by Qi on 12/4/2017.
 */

public class ActiveAccountListView extends AppCompatActivity {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.listview_active_inactive_account);

    ArrayList<String> account = getIntent().getExtras().getStringArrayList("active");

    ArrayAdapter<String> adapter = new ArrayAdapter(getApplicationContext(),
        android.R.layout.simple_list_item_1, account);
    ListView testListView = (ListView) findViewById(R.id.inactive_account);
    testListView.setAdapter(adapter);
  }
}
