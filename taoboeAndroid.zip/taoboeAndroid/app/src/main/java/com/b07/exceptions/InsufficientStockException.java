package com.b07.exceptions;

public class InsufficientStockException extends Exception {

  private static final long serialVersionUID = 4350714160572090389L;

  public InsufficientStockException() {
  }

  public InsufficientStockException(String message) {
    super(message);
  }

  public InsufficientStockException(Throwable cause) {
    super(cause);
  }

  public InsufficientStockException(String message, Throwable cause) {
    super(message, cause);
  }

  public InsufficientStockException(String message, Throwable cause, boolean enableSuppression,
      boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }

}
