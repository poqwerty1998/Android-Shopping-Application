package com.b07.store;

import com.b07.inventory.Item;
import com.b07.models.User;
import java.math.BigDecimal;
import java.util.HashMap;

public class SaleImpl implements Sale {

  private int id;
  private User user;
  private BigDecimal totalPrice;
  private HashMap<Item, Integer> itemMap;


  public SaleImpl(int id, User user, BigDecimal totalPrice, HashMap<Item, Integer> itemMap) {
    this.id = id;
    this.user = user;
    this.totalPrice = totalPrice;
    this.itemMap = itemMap;
  }

  @Override
  public int getId() {
    return this.id;
  }

  @Override
  public void setId(int id) {
    this.id = id;
  }

  @Override
  public User getUser() {
    return this.user;
  }

  @Override
  public void setUser(User user) {
    this.user = user;
  }

  @Override
  public BigDecimal getTotalPrice() {
    return this.totalPrice;
  }

  @Override
  public void setTotalPrice(BigDecimal price) {
    this.totalPrice = price;
  }

  @Override
  public HashMap<Item, Integer> getItemMap() {
    return this.itemMap;
  }

  @Override
  public void setItemMap(HashMap<Item, Integer> itemMap) {
    this.itemMap = itemMap;
  }
}
