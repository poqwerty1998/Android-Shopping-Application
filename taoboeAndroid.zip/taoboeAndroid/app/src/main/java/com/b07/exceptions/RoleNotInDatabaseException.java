package com.b07.exceptions;

public class RoleNotInDatabaseException extends Exception {

  private static final long serialVersionUID = 6629911163143517688L;

  public RoleNotInDatabaseException() {
  }

  public RoleNotInDatabaseException(String message) {
    super(message);
  }

  public RoleNotInDatabaseException(Throwable cause) {
    super(cause);
  }

  public RoleNotInDatabaseException(String message, Throwable cause) {
    super(message, cause);
  }

  public RoleNotInDatabaseException(String message, Throwable cause, boolean enableSuppression,
      boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }

}
