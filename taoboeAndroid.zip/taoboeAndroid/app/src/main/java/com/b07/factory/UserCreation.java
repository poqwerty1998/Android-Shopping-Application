package com.b07.factory;

import android.content.Context;
import java.sql.SQLException;

import com.b07.exceptions.RoleIdNotInDatabaseException;
import com.b07.models.Admin;
import com.b07.models.Customer;
import com.b07.models.Roles;
import com.b07.models.User;

public class UserCreation {

  private Context context;

  public UserCreation(Context context) {
    this.context = context;
  }

  /**
   * Given the type of user, id, name, age, and address of a user, create
   * appropriate User object based on given type.
   *
   * @param type is the role of user.
   * @param id is the id of the user.
   * @param name is name of the user.
   * @param age is the age of the user.
   * @param address is the address of the user.
   * @throws SQLException if something goes wrong with SQL database.
   * @throws RoleIdNotInDatabaseException if the type of user does not exist in database.
   */
  public User createUser(String type, Integer id, String name, Integer age, String address)
      throws SQLException, RoleIdNotInDatabaseException {
    User user = null;
    if (type.equalsIgnoreCase(Roles.ADMIN.toString())) {
      user = new Admin(id, name, age, address, context);
    } else if (type.equalsIgnoreCase(Roles.CUSTOMER.toString())) {
      user = new Customer(id, name, age, address, context);
    }
    return user;
  }

  /**
   * Given the type of user, id, name, age, and address of a user, create
   * appropriate User object based on given type. Also takes in a boolean which
   * represents if the user is authenticated or not.
   *
   * @param type is the role of user.
   * @param id is the id of the user.
   * @param name is name of the user.
   * @param age is the age of the user.
   * @param address is the address of the user.
   * @param authenticated is if the user is authenticated with database or not.
   * @throws SQLException if something goes wrong with SQL database.
   * @throws RoleIdNotInDatabaseException if the type of user does not exist in database.
   */
  public User createUser(String type, Integer id, String name, String address, Integer age,
      boolean authenticated) throws SQLException, RoleIdNotInDatabaseException {
    User user = null;
    if (type.equalsIgnoreCase(Roles.ADMIN.toString())) {
      user = new Admin(id, name, age, address, authenticated, context);
    } else if (type.equalsIgnoreCase(Roles.CUSTOMER.toString())) {
      user = new Customer(id, name, age, address, authenticated, context);
    }
    return user;
  }
}
